#!/usr/bin/env python3
"""
Benchmark: 1 chapter, merge 10 vs tanpa merge.

- Mode baseline (tanpa merge):  tiap gambar sumber -> AVIF w500 q40 (N file).
- Mode merge (10 strip):        gambar berurutan ditumpuk VERTIKAL jadi maks 10 grup
                               -> tiap grup 1 AVIF w500 q40 (M file, M = min(N, 10)).

PENTING: ini MERGE, bukan crop. Nggak ada pixel dibuang. Yang di-merge cuma
"beberapa gambar jadi 1 file", bukan "1 gambar dipotong jadi beberapa file".

Pakai kode merge yang SAMA dengan scraper (scraper.base.BaseScraper), jadi angka
benchmark di sini = angka pipeline asli.

Contoh:
    python bench_one_chapter.py downloads/Manga/chapter-003.cbz -o bench_ch003
    python bench_one_chapter.py bench_ch003/baseline -o bench_ch003
"""
import os
import io
import sys
import argparse
import zipfile
from pathlib import Path
from typing import List, Tuple

import pillow_avif  # noqa: F401  (register AVIF plugin ke Pillow)
from PIL import Image

from scraper.base import BaseScraper

IMAGE_EXTS = ('.avif', '.webp', '.jpg', '.jpeg', '.png', '.gif', '.bmp')


class _BenchScraper(BaseScraper):
    """Subclass tipis biar benchmark jalan pakai kode merge PRODUKSI."""

    def __init__(self, workspace: Path):
        super().__init__(str(workspace))

    def search(self, query: str):
        return []

    def get_manga_detail(self, url: str):
        return None

    def get_chapter_images_ordered(self, url: str):
        return []


def load_source_images(source: Path) -> List[Tuple[str, bytes]]:
    """Ambil gambar sumber sesuai urutan baca (CBZ atau folder)."""
    items: List[Tuple[str, bytes]] = []

    if source.is_dir():
        files = sorted(p for p in source.iterdir()
                       if p.is_file() and p.suffix.lower() in IMAGE_EXTS)
        for p in files:
            items.append((p.name, p.read_bytes()))
        return items

    if source.suffix.lower() == '.cbz':
        with zipfile.ZipFile(source, 'r') as zf:
            for name in sorted(zf.namelist()):
                if name.lower().endswith(IMAGE_EXTS):
                    items.append((name, zf.read(name)))
        return items

    raise SystemExit(f"❌ Sumber harus folder gambar atau file .cbz: {source}")


def save_avif(out_dir: Path, name: str, data: bytes) -> int:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / name
    with open(path, 'wb') as f:
        f.write(data)
    return len(data)


def run_baseline(scraper: _BenchScraper, images: List[Tuple[str, bytes]],
                out_dir: Path) -> Tuple[int, int]:
    """N gambar -> N AVIF (perilaku sebelum merge)."""
    total, count = 0, 0
    for i, (_name, data) in enumerate(images, 1):
        avif = scraper._convert_to_avif(data)
        if not avif:
            print(f"  ⚠️  gambar {i} gagal dikonvert, dilewati")
            continue
        total += save_avif(out_dir, f"{i:03d}.avif", avif)
        count += 1
    return count, total


def run_merge(scraper: _BenchScraper, images: List[Tuple[str, bytes]],
              out_dir: Path, target: int) -> Tuple[int, int, List[int], bool]:
    """N gambar -> maks `target` AVIF (tumpuk vertikal, tanpa crop).

    Return: (jumlah file, total bytes, jumlah gambar per grup, strip-utuh?)
    """
    groups = scraper.split_into_merge_groups(images, target)
    total, count, sizes = 0, 0, []
    intact = True

    for idx, group in enumerate(groups, 1):
        merged = scraper._merge_group_to_avif([d for _n, d in group])
        if merged:
            total += save_avif(out_dir, f"part_{idx:02d}.avif", merged)
            count += 1
            sizes.append(len(group))
            continue

        # Fallback produksi: strip gagal di-encode -> simpan per gambar (urutan tetap)
        intact = False
        saved = 0
        for j, (_n, data) in enumerate(group, 1):
            avif = scraper._convert_to_avif(data)
            if avif:
                total += save_avif(out_dir, f"part_{idx:02d}-{j:02d}.avif", avif)
                count += 1
                saved += 1
        sizes.append(saved)

    return count, total, sizes, intact


def verify_no_crop(scraper: _BenchScraper, images: List[Tuple[str, bytes]],
                   merged_dir: Path, target: int) -> bool:
    """Buktiin merge != crop: total tinggi & lebar per strip HARUS sama persis
    dengan gabungan gambar sumbernya."""
    groups = scraper.split_into_merge_groups(images, target)
    ok = True

    for idx, group in enumerate(groups, 1):
        expected_w = 0
        expected_h = 0
        for _n, data in group:
            im = scraper._prepare_image(Image.open(io.BytesIO(data)))
            expected_w = max(expected_w, im.width)
            expected_h += im.height

        part = merged_dir / f"part_{idx:02d}.avif"
        if not part.exists():          # fallback per-gambar, cek manual di bawah
            continue

        actual_w, actual_h = Image.open(part).size
        if (actual_w, actual_h) != (expected_w, expected_h):
            print(f"  ❌ part_{idx:02d}: {actual_w}x{actual_h} "
                  f"≠ ekspektasi {expected_w}x{expected_h} (ada yang kepotong!)")
            ok = False

    return ok


def main():
    parser = argparse.ArgumentParser(description="Benchmark merge-10 vs baseline")
    parser.add_argument("source", help="Folder gambar sumber atau file .cbz")
    parser.add_argument("-o", "--output", default="bench_output", help="Folder output")
    parser.add_argument("--target", type=int, default=10, help="Jumlah gambar hasil merge")
    parser.add_argument("--no-merge", action="store_true", help="Cuma benchmark baseline")
    args = parser.parse_args()

    source = Path(args.source)
    if not source.exists():
        print(f"❌ Sumber tidak ada: {source}")
        sys.exit(1)

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    scraper = _BenchScraper(out)

    images = load_source_images(source)
    if not images:
        print(f"❌ Nggak ada gambar di {source}")
        sys.exit(1)

    n = len(images)
    print(f"🔍 Sumber: {source} -> {n} gambar")

    print("\n📦 BASELINE (tanpa merge)...")
    base_files, base_total = run_baseline(scraper, images, out / "baseline")
    _print_stat("Baseline", base_files, base_total)

    if args.no_merge:
        return

    print(f"\n📦 MERGE (tumpuk vertikal, maks {args.target} gambar)...")
    merge_files, merge_total, group_sizes, intact = run_merge(
        scraper, images, out / "merged_10", args.target)
    _print_stat("Merge", merge_files, merge_total)
    print(f"    Gambar per strip: {group_sizes}")

    print("\n🔎 Verifikasi merge (bukan crop):")
    if verify_no_crop(scraper, images, out / "merged_10", args.target):
        print("  ✅ tidak ada pixel hilang / kepotong")
    if not intact:
        print("  ℹ️  ada grup yang fallback per-gambar (strip kepanjangan buat AVIF)")

    print("\n=== PERBANDINGAN ===")
    print(f"Baseline : {base_files:>3} file | {base_total/1024:8.1f} KB "
          f"| rata-rata {base_total/max(base_files,1)/1024:5.1f} KB/file")
    print(f"Merge    : {merge_files:>3} file | {merge_total/1024:8.1f} KB "
          f"| rata-rata {merge_total/max(merge_files,1)/1024:5.1f} KB/file")
    if base_total:
        diff = merge_total - base_total
        print(f"Selisih  : {diff/1024:+.1f} KB ({diff/base_total*100:+.1f}%) "
              f"-> merge {'lebih kecil ✅' if diff < 0 else 'lebih besar ❌'}")


def _print_stat(label: str, files: int, total: int):
    print(f"    {label}: {files} file, {total/1024:.1f} KB")


if __name__ == "__main__":
    main()
