#!/usr/bin/env python3
"""Kalibrasi banyak sample pillow-avif-plugin (SVT v4.1.0) supaya UKURANNYA
pas ~28.5 KB (setara file ffmpeg+libsvtav1 crf 44 = 28.544 B), lalu ukur
kualitasnya (SSIM + detail) buat dibandingkan.

Knob yang dipakai: advanced 'crf' (= QP efektif di jalur libavif) + 'tune'.
Tune SVT: 1 = PSNR (default), 2 = SSIM, 3 = IQ (still image), 4 = MS-SSIM (still image).
"""
import io
import re
import statistics
import subprocess
import time
from pathlib import Path

from PIL import Image, ImageFilter
import pillow_avif  # noqa: F401

HERE = Path(__file__).resolve().parent
D = HERE / "bench_page_compare"
P = D / "page_w500.png"
OUT = HERE.parent  # nanti di-copy ke root repo
T = D / "_pillow_match"
T.mkdir(parents=True, exist_ok=True)
im = Image.open(P).convert("RGB")
LAP = ImageFilter.Kernel((3, 3), [-1, -1, -1, -1, 8, -1, -1, -1, -1], scale=1, offset=0)
TARGET = 28500          # byte, target ukuran
TOL = 400               # toleransi


def encode(o, speed, crf, tune):
    b = io.BytesIO()
    im.save(b, "AVIF", codec="svt", speed=speed, quality=40,
            advanced=[("tune", tune), ("crf", crf)])
    o.write_bytes(b.getvalue())
    return o.stat().st_size


def quality(o):
    png = T / f"q_{o.stem}.png"
    subprocess.run(["avifdec", str(o), str(png), "-q", "100"], capture_output=True)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(png), "-i", str(P),
                        "-lavfi", "ssim", "-f", "null", "-"], capture_output=True, text=True)
    v = float(re.search(r"All:([0-9.]+)", r.stderr).group(1))
    d = statistics.pvariance(list(Image.open(png).convert("L").filter(LAP).get_flattened_data()))
    return v, d


def calibrate(speed, tune, lo=16, hi=70):
    """Binary search crf sampai ukuran mendekati TARGET."""
    best = None
    while lo <= hi:
        mid = (lo + hi) // 2
        o = T / f"cal_s{speed}_t{tune}_crf{mid}.avif"
        n = encode(o, speed, mid, tune)
        if best is None or abs(n - TARGET) < abs(best[2] - TARGET):
            best = (mid, o, n)
        if n > TARGET:
            lo = mid + 1     # terlalu besar -> crf dinaikkan
        else:
            hi = mid - 1
    return best


def ssim_of(avif):
    png = T / f"x_{Path(avif).stem}.png"
    subprocess.run(["avifdec", str(avif), str(png), "-q", "100"], capture_output=True)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(png), "-i", str(P),
                        "-lavfi", "ssim", "-f", "null", "-"], capture_output=True, text=True)
    m = re.search(r"All:([0-9.]+)", r.stderr or "")
    return float(m.group(1)) if m else float("nan")


print(f"target ukuran: {TARGET:,} B  (file ffmpeg crf44 = 28.544 B, SSIM 0.9451)\n")
print(f"{'sample':30} {'crf':>4} {'bytes':>8} {'SSIM':>8} {'detail':>7} {'waktu':>7}")

rows = []
for speed in (5, 6):
    for tune in (1, 2, 3, 4):
        t0 = time.perf_counter()
        crf, o, n = calibrate(speed, tune)
        dt = time.perf_counter() - t0
        v, d = quality(o)
        name = f"svt_pillow_s{speed}_tune{tune}_28k.avif"
        (T / name).write_bytes(o.read_bytes())
        rows.append((speed, tune, crf, n, v, d, name))
        print(f"{name:30} {crf:>4} {n:>8,} {v:>8.4f} {d:>7.0f} {dt/8:>6.2f}s")

print("\n== ringkasan (ukuran ~setara, kualitas tertinggi di atas) ==")
for speed, tune, crf, n, v, d, name in sorted(rows, key=lambda r: -r[4]):
    tn = {1: "PSNR", 2: "SSIM", 3: "IQ(still)", 4: "MS-SSIM(still)"}[tune]
    print(f"  {name:30} tune {tune} {tn:16} {n:,}B  SSIM {v:.4f}  detail {d:.0f}")
