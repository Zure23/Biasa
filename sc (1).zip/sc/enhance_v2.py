#!/usr/bin/env python3
"""
Image Enhancement V2 - Preserve Colors, Only Sharpen
Tidak mengubah warna, hanya bikin gambar lebih tajam
"""
import os
import io
import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import pillow_avif

# Settings
OUTPUT_DIR = "enhanced_v2"
TARGET_WIDTH = 500
QUALITY = 40

def sharpen_only(original):
    """
    Hanya sharpen TANPA mengubah warna
    - Tidak ada contrast change
    - Tidak ada brightness change
    - Tidak ada color change
    """
    # Convert to numpy for processing
    img_array = np.array(original).astype(np.float32)
    
    # Method 1: Unsharp Mask (sharpen only, no color change)
    # Create blurred version
    img_blur = cv2.GaussianBlur(img_array, (0, 0), 3)
    
    # Unsharp mask formula: original + amount * (original - blurred)
    amount = 1.5  # Sharpening strength
    sharpened = img_array + amount * (img_array - img_blur)
    
    # Clip values to valid range
    sharpened = np.clip(sharpened, 0, 255).astype(np.uint8)
    
    return Image.fromarray(sharpened)

def sharpen_with_detail_preserve(original):
    """
    Sharpen dengan detail preservation
    Lebih detail tapi tetap preserve warna
    """
    img_array = np.array(original).astype(np.float32)
    
    # Method: High-pass filter overlay
    # Create low-pass (blur) version
    low_pass = cv2.GaussianBlur(img_array, (0, 0), 2)
    
    # High-pass = original - low_pass (detail only)
    high_pass = img_array - low_pass
    
    # Add high-pass back to original (enhance detail)
    amount = 0.8  # Conservative sharpening
    sharpened = img_array + amount * high_pass
    
    # Clip
    sharpened = np.clip(sharpened, 0, 255).astype(np.uint8)
    
    return Image.fromarray(sharpened)

def enhance_images():
    """Download, sharpen, and convert"""
    
    from scraper import KomikindoScraper
    
    # Create output directories
    os.makedirs(f"{OUTPUT_DIR}/original", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/sharpen_v1", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/sharpen_v2", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/webp", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/avif", exist_ok=True)
    
    scraper = KomikindoScraper()
    
    print("=== IMAGE ENHANCEMENT V2 ===")
    print()
    print("Method: Sharpen Only (No Color Change)")
    print()
    
    # Get ordered images
    print("Getting images from komikindo.ch...")
    ordered = scraper.get_chapter_images_ordered('https://komikindo.ch/magic-emperor-chapter-906/')
    print(f"Found {len(ordered)} images")
    print()
    
    total_original = 0
    total_sharpen_v1 = 0
    total_sharpen_v2 = 0
    total_webp = 0
    total_avif = 0
    
    for img in ordered:
        order = img['order']
        url = img['url']
        
        print(f"Processing image {order}/{len(ordered)}...")
        
        # Download image
        resp = scraper.session.get(url, timeout=30)
        original_data = resp.content
        original_size = len(original_data)
        total_original += original_size
        
        # Save original
        original_path = f"{OUTPUT_DIR}/original/{order:03d}.jpeg"
        with open(original_path, 'wb') as f:
            f.write(original_data)
        
        # Open image
        image = Image.open(io.BytesIO(original_data))
        orig_width, orig_height = image.size
        
        # Resize to target width
        if orig_width > TARGET_WIDTH:
            ratio = TARGET_WIDTH / orig_width
            new_height = int(orig_height * ratio)
            image = image.resize((TARGET_WIDTH, new_height), Image.LANCZOS)
        
        # Check color preservation
        orig_arr = np.array(image)
        print(f"  Original avg color: R={orig_arr[:,:,0].mean():.0f}, G={orig_arr[:,:,1].mean():.0f}, B={orig_arr[:,:,2].mean():.0f}")
        
        # Sharpen V1 (Unsharp Mask)
        sharpen_v1 = sharpen_only(image)
        sharpen_v1.save(f"{OUTPUT_DIR}/sharpen_v1/{order:03d}.jpeg", quality=95)
        sharpen_v1_size = os.path.getsize(f"{OUTPUT_DIR}/sharpen_v1/{order:03d}.jpeg")
        total_sharpen_v1 += sharpen_v1_size
        
        # Check V1 color preservation
        v1_arr = np.array(sharpen_v1)
        print(f"  V1 avg color:      R={v1_arr[:,:,0].mean():.0f}, G={v1_arr[:,:,1].mean():.0f}, B={v1_arr[:,:,2].mean():.0f}")
        
        # Sharpen V2 (High-pass detail preserve)
        sharpen_v2 = sharpen_with_detail_preserve(image)
        sharpen_v2.save(f"{OUTPUT_DIR}/sharpen_v2/{order:03d}.jpeg", quality=95)
        sharpen_v2_size = os.path.getsize(f"{OUTPUT_DIR}/sharpen_v2/{order:03d}.jpeg")
        total_sharpen_v2 += sharpen_v2_size
        
        # Check V2 color preservation
        v2_arr = np.array(sharpen_v2)
        print(f"  V2 avg color:      R={v2_arr[:,:,0].mean():.0f}, G={v2_arr[:,:,1].mean():.0f}, B={v2_arr[:,:,2].mean():.0f}")
        
        # Use V2 for final conversion
        final_image = sharpen_v2
        
        # Convert to WebP
        webp_path = f"{OUTPUT_DIR}/webp/{order:03d}.webp"
        final_image.save(webp_path, "WEBP", quality=QUALITY)
        webp_size = os.path.getsize(webp_path)
        total_webp += webp_size
        
        # Convert to AVIF
        avif_path = f"{OUTPUT_DIR}/avif/{order:03d}.avif"
        final_image.save(avif_path, "AVIF", quality=QUALITY)
        avif_size = os.path.getsize(avif_path)
        total_avif += avif_size
        
        print(f"  Original:    {orig_width}x{orig_height} | {original_size/1024:.1f} KB")
        print(f"  Sharpen V1:      | {sharpen_v1_size/1024:.1f} KB")
        print(f"  Sharpen V2:      | {sharpen_v2_size/1024:.1f} KB")
        print(f"  WebP:        | {webp_size/1024:.1f} KB ({(1-webp_size/original_size)*100:.1f}% smaller)")
        print(f"  AVIF:        | {avif_size/1024:.1f} KB ({(1-avif_size/original_size)*100:.1f}% smaller)")
        print()
    
    print("=== SUMMARY ===")
    print(f"Original:       {total_original/1024/1024:.2f} MB")
    print(f"Sharpen V1:     {total_sharpen_v1/1024/1024:.2f} MB")
    print(f"Sharpen V2:     {total_sharpen_v2/1024/1024:.2f} MB")
    print(f"WebP:           {total_webp/1024/1024:.2f} MB ({(1-total_webp/total_original)*100:.1f}% smaller)")
    print(f"AVIF:           {total_avif/1024/1024:.2f} MB ({(1-total_avif/total_original)*100:.1f}% smaller)")
    print()
    print(f"Files saved to: {OUTPUT_DIR}/")

if __name__ == "__main__":
    enhance_images()
