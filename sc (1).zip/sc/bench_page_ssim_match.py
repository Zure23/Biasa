#!/usr/bin/env python3
"""
Benchmark 1 GAMBAR (judul + nomor halaman bebas):
Sisi A = AVIF dari SCRAPER ASLI (Pillow/pillow-avif-plugin, w500 q40, speed 8)
Sisi B = AVIF dari SVT-AV1 (avifenc -c svt -s 5 --yuv 420), q disetel sampai
         SSIM-nya setara dengan sisi A.

Scraper di folder scraper/ TIDAK diubah sama sekali (cuma di-import).

Pakai:
    python3 bench_page_ssim_match.py --manga-url <url> --chapter 1 --page 4
"""
import io
import os
import re
import sys
import argparse
import subprocess
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PIL import Image
import pillow_avif  # noqa: F401

from scraper import KomikuScraper  # scraper asli, tidak diubah

# SVT di-encode lewat ffmpeg (libsvtav1), BUKAN avifenc: avifenc/SVT v1.7.0 selalu
# menulis tag color_range=limited walau isinya full-range, sehingga decoder yang
# menghormati flag (dav1d/ffmpeg) menampilkan kontras palsu -> perbandingan jadi curang.
SVT_PRESET = "5"
SVT_CRF_SWEEP = [28, 32, 34, 36, 38, 40, 42, 44, 46, 48]
OUT_DIR = Path(__file__).resolve().parent / "bench_page_compare"


def sh(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def _decode_ref(avif_path, tag):
    """Decode pakai avifdec (libavif, referensi) supaya SSIM tidak tergantung
    cara tiap decoder menafsirkan flag range."""
    png = OUT_DIR / f"_dec_{tag}.png"
    sh(["avifdec", str(avif_path), str(png), "-q", "100"])
    return png if png.exists() else avif_path


def ssim(a, b, a_is_avif=True):
    aa = _decode_ref(a, "a") if a_is_avif else a
    bb = _decode_ref(b, "b") if str(b).endswith(".avif") else b
    r = sh(["ffmpeg", "-hide_banner", "-i", str(aa), "-i", str(bb),
            "-lavfi", "ssim", "-f", "null", "-"])
    for line in (r.stderr or "").splitlines():
        if "SSIM" in line and "All:" in line:
            try:
                return float(line.split("All:")[1].split()[0].split("(")[0])
            except Exception:
                return float("nan")
    return float("nan")


def even_pad(im):
    w, h = im.size
    ew, eh = w + (w & 1), h + (h & 1)
    if (ew, eh) == (w, h):
        return im
    c = Image.new("RGB", (ew, eh), (0, 0, 0))
    c.paste(im, (0, 0))
    return c


def pick_chapter(scraper, manga_url, chapter_no):
    detail = scraper.get_manga_detail(manga_url)
    if not detail:
        raise SystemExit("gagal ambil detail manga")
    for ch in detail["chapters"]:
        m = re.search(r"(\d+(?:\.\d+)?)", ch["title"])
        if m and abs(float(m.group(1)) - chapter_no) < 1e-6:
            return detail, ch
    raise SystemExit(f"chapter {chapter_no} tidak ketemu")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manga-url", required=True)
    ap.add_argument("--chapter", type=int, default=1)
    ap.add_argument("--page", type=int, default=4)
    args = ap.parse_args()

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    scraper = KomikuScraper(str(OUT_DIR))

    print(f"🔎 cari chapter {args.chapter} ...")
    detail, chapter = pick_chapter(scraper, args.manga_url, args.chapter)
    print(f"   {detail['title']} -> {chapter['title']}")
    print(f"   {chapter['url']}")

    imgs = scraper.get_chapter_images_ordered(chapter["url"])
    if len(imgs) < args.page:
        raise SystemExit(f"halaman {args.page} tidak ada (cuma {len(imgs)})")
    item = imgs[args.page - 1]
    print(f"   {len(imgs)} gambar; ambil halaman {args.page}: {item['url'].split('/')[-1]}")

    data = scraper._download_image_with_retry(item["url"])
    if not data:
        raise SystemExit("download gagal")
    ext = scraper._detect_image_ext(data)
    (OUT_DIR / f"original{ext}").write_bytes(data)

    im = scraper._prepare_image(Image.open(io.BytesIO(data)))  # method asli scraper
    png = OUT_DIR / "page_w500.png"
    im.save(png)
    png_even = OUT_DIR / "page_w500_even.png"
    even_pad(im).save(png_even)
    print(f"   w500: {im.width}x{im.height}  (SVT input {Image.open(png_even).size})")

    # --- Sisi A: encoder scraper asli ---
    avif_scraper = OUT_DIR / "avif_scraper.avif"
    avif_scraper.write_bytes(scraper._encode_avif(Image.open(png)))
    s_a = avif_scraper.stat().st_size
    ssim_a = ssim(avif_scraper, png)
    print(f"\n🟦 SCRAPER w500 q40 -> {s_a:,} B   SSIM {ssim_a:.4f}")

    # --- Sisi B: sweep CRF SVT (ffmpeg+libsvtav1, tag range full) cari SSIM setara ---
    print(f"\n🟨 SVT-AV1 (libsvtav1 preset {SVT_PRESET}, yuv420, range full) sweep CRF untuk samakan SSIM ...")
    print(f"{'crf':>4} {'bytes':>9} {'SSIM':>7} {'vs scraper':>11}")
    best = None
    for q in SVT_CRF_SWEEP:
        out = OUT_DIR / f"avif_svt_crf{q}.avif"
        sh(["ffmpeg", "-v", "error", "-y", "-i", str(png_even),
            "-vf", "scale=in_range=full:out_range=full",
            "-frames:v", "1", "-c:v", "libsvtav1", "-crf", str(q),
            "-preset", SVT_PRESET, "-pix_fmt", "yuv420p", "-color_range", "pc", str(out)])
        if not out.exists():
            print(f"{q:>4} gagal")
            continue
        n = out.stat().st_size
        v = ssim(out, png_even)
        pct = (n - s_a) / s_a * 100
        print(f"{q:>4} {n:>9,} {v:>7.4f} {pct:>+10.2f}%")
        # pilih q dengan SSIM >= scraper tapi ukuran terkecil
        if v == v and v >= ssim_a:
            if best is None or n < best[1]:
                best = (q, n, v, out)

    if best is None:
        raise SystemExit("tidak ada q SVT yang mencapai SSIM scraper")

    q, n, v, out = best
    print(f"\n✅ terpilih SVT CRF {q}: {n:,} B  SSIM {v:.4f} vs scraper q40 {s_a:,} B SSIM {ssim_a:.4f}")
    d = n - s_a
    print(f"   selisih {d:+,} B -> {'HEMAT' if d < 0 else 'RUGI'} {abs(d)/s_a*100:.2f}%")

    latest = OUT_DIR / "_latest.json"
    import json
    latest.write_text(json.dumps({
        "manga": detail["title"], "chapter": chapter["title"],
        "page": args.page, "source_url": item["url"],
        "dim": list(im.size),
        "scraper": {"file": str(avif_scraper), "bytes": s_a, "ssim": round(ssim_a, 4)},
        "svt": {"q": q, "file": str(out), "bytes": n, "ssim": round(v, 4)},
        "delta_bytes": d, "delta_pct": round(d / s_a * 100, 2),
    }, indent=2))
    print(f"\n📁 {OUT_DIR}")


if __name__ == "__main__":
    main()
