#!/usr/bin/env python3
"""Ronde 2: knob 'crf' via advanced= + tune still-picture (3/4), dikalibrasi sampai
SSIM setara SVT crf 44 (jalur ffmpeg)."""
import io
import re
import statistics
import subprocess
import time
from pathlib import Path

from PIL import Image, ImageFilter
import pillow_avif  # noqa: F401

D = Path(__file__).resolve().parent / "bench_page_compare"
P = D / "page_w500.png"
T = D / "_svt_still2"
T.mkdir(parents=True, exist_ok=True)
im = Image.open(P).convert("RGB")
LAP = ImageFilter.Kernel((3, 3), [-1, -1, -1, -1, 8, -1, -1, -1, -1], scale=1, offset=0)
TARGET_B, TARGET_SSIM = 28544, 0.9451


def measure(o):
    png = T / f"m_{o.stem}.png"
    subprocess.run(["avifdec", str(o), str(png), "-q", "100"], capture_output=True)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(png), "-i", str(P),
                        "-lavfi", "ssim", "-f", "null", "-"], capture_output=True, text=True)
    m = re.search(r"All:([0-9.]+)", r.stderr or "")
    v = float(m.group(1)) if m else float("nan")
    i = Image.open(png).convert("L")
    d = statistics.pvariance(list(i.filter(LAP).get_flattened_data()))
    return v, d


def enc(name, speed, quality, advanced):
    o = T / f"{name}.avif"
    t = time.perf_counter()
    b = io.BytesIO()
    im.save(b, "AVIF", codec="svt", speed=speed, quality=quality, advanced=advanced)
    o.write_bytes(b.getvalue())
    return o, time.perf_counter() - t


print(f"target crf44 (ffmpeg+libsvtav1, SVT 1.7.0): {TARGET_B:,} B  SSIM {TARGET_SSIM:.4f}")
print(f"catatan: quality libavif -> QP; advanced 'crf' menimpa QP (terbukti jalan)\n")
print(f"{'setelan':40} {'waktu':>7} {'bytes':>9} {'SSIM':>8} {'detail':>7} {'vs target':>10}")

results = []
for tune in (1, 2, 3, 4):
    for crf in (38, 40, 42, 44):
        name = f"s6_t{tune}_crf{crf}"
        o, dt = enc(name, 6, 40, [("tune", tune), ("crf", crf)])
        v, d = measure(o)
        n = o.stat().st_size
        print(f"{name:40} {dt:>6.2f}s {n:>8,}B {v:>8.4f} {d:>7.0f} {(n-TARGET_B)/TARGET_B*100:>+9.1f}%")
        results.append((abs(v - TARGET_SSIM), name, n, v, dt, d))

print("\n== paling dekat ke kualitas target (|delta SSIM| terkecil) ==")
for delta, name, n, v, dt, d in sorted(results)[:6]:
    print(f"{name:14} SSIM {v:.4f} (delta {v-TARGET_SSIM:+.4f})  {n:,}B  {(n-TARGET_B)/TARGET_B*100:+.1f}%  {dt:.2f}s")
