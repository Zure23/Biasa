#!/usr/bin/env python3
"""Benchmark setelan SVT-AV1 "still picture" (hasil riset docs SVT-AV1) lewat plugin.

Dasar riset (SVT-AV1 Docs/Parameters.md):
  --tune 3 = IQ (still image only), --tune 4 = MS-SSIM (still image), default 1 = PSNR
  --avif 1 = optimasi still-picture (efisiensi naik, memory turun)   [SVT >= 4.0]
  --enable-variance-boost 1 / --variance-boost-strength
  --max-tx-size 32 = hindari blur 64-pt transform (bagus buat still image)
  --enable-qm 1 = quantization matrices
  --sharpness dipakai di tune 3/4
Semua lewat pillow-avif-plugin (SVT v4.1.0) karena ffmpeg di sini pakai SVT v1.7.0
yang belum kenal tune 3/4.
"""
import io
import re
import statistics
import subprocess
import time
from pathlib import Path

from PIL import Image, ImageFilter
import pillow_avif  # noqa: F401

D = Path(__file__).resolve().parent / "bench_page_compare"
P = D / "page_w500.png"
T = D / "_svt_still"
T.mkdir(parents=True, exist_ok=True)
im = Image.open(P).convert("RGB")
LAP = ImageFilter.Kernel((3, 3), [-1, -1, -1, -1, 8, -1, -1, -1, -1], scale=1, offset=0)

# target pembanding: SVT via ffmpeg crf 44 (jalur lama)
TARGET_B, TARGET_SSIM = 28544, 0.9451


def ssim(avif):
    out = T / f"s_{avif.stem}.png"
    subprocess.run(["avifdec", str(avif), str(out), "-q", "100"], capture_output=True)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(out), "-i", str(P),
                        "-lavfi", "ssim", "-f", "null", "-"], capture_output=True, text=True)
    m = re.search(r"All:([0-9.]+)", r.stderr or "")
    return float(m.group(1)) if m else float("nan")


def detail(avif):
    out = T / f"s_{avif.stem}.png"
    i = Image.open(out).convert("L")
    l = list(i.filter(LAP).get_flattened_data())
    return statistics.pvariance(l)


def enc(name, speed, quality, advanced=None):
    o = T / f"{name}.avif"
    t = time.perf_counter()
    b = io.BytesIO()
    im.save(b, "AVIF", codec="svt", speed=speed, quality=quality, advanced=advanced)
    o.write_bytes(b.getvalue())
    dt = time.perf_counter() - t
    return o, dt


def row(name, o, dt):
    v, d = ssim(o), detail(o)
    n = o.stat().st_size
    print(f"{name:34} {dt:>6.2f}s {n:>8,}B {v:>8.4f} {d:>8.0f} {(n-TARGET_B)/TARGET_B*100:>+8.1f}%")


print(f"target crf44 (ffmpeg, SVT 1.7.0): {TARGET_B:,} B  SSIM {TARGET_SSIM:.4f}  detail 2319\n")
print(f"{'setelan plugin (SVT 4.1.0)':34} {'waktu':>7} {'bytes':>9} {'SSIM':>8} {'detail':>8} {'vs crf44':>9}")

CONFIGS = [
    ("s6 q36 baseline", 6, 36, None),
    ("s6 q36 tune=4 MS-SSIM", 6, 36, [("tune", 4)]),
    ("s6 q36 tune=3 IQ", 6, 36, [("tune", 3)]),
    ("s6 q36 avif=1", 6, 36, [("avif", 1)]),
    ("s6 q36 tune=4 avif=1", 6, 36, [("tune", 4), ("avif", 1)]),
    ("s6 q36 tune=3 avif=1", 6, 36, [("tune", 3), ("avif", 1)]),
    ("s6 q36 tune=4 avif=1 vb=1", 6, 36, [("tune", 4), ("avif", 1), ("enable-variance-boost", 1)]),
    ("s6 q36 tune=4 avif=1 txt32", 6, 36, [("tune", 4), ("avif", 1), ("max-tx-size", 32)]),
    ("s6 q36 tune=4 avif=1 qm=1", 6, 36, [("tune", 4), ("avif", 1), ("enable-qm", 1)]),
    ("s6 q36 tune=4 avif=1 sharp1", 6, 36, [("tune", 4), ("avif", 1), ("sharpness", 1)]),
    ("s6 q36 tune=0 VQ", 6, 36, [("tune", 0)]),
    ("s6 q36 tune=2 SSIM", 6, 36, [("tune", 2)]),
]

rows = []
for name, sp, q, adv in CONFIGS:
    try:
        o, dt = enc(name.replace(" ", "_"), sp, q, adv)
        row(name, o, dt)
        rows.append((name, o, dt, adv))
    except Exception as e:
        print(f"{name:34} GAGAL {type(e).__name__}: {e}")
