# 📚 Comic Scraper

Download manga dari situs Indonesia: **komiku.org**, **komikindo.ch**, dan **softkomik.co**

## 🚀 Features

- 🔍 Search manga by title
- 📖 Get manga details (genres, synopsis, info)
- 📥 Download single chapter atau multiple chapters
- 📁 Organized folder structure:
  ```
  downloads/
  └── Manga_Title/
      ├── cover.jpg
      ├── info.json
      └── Chapter_001/
          ├── 001.webp
          ├── 002.webp
          └── ...
  ```

## 📦 Installation

```bash
cd comic-scraper
pip install -r requirements.txt
```

## 🎯 Usage

### Interactive Mode

```bash
python main.py
```

### Command Line Arguments

```bash
# Search and download from komiku.org
python main.py -s komiku -q "martial peak" -d all

# Download specific chapters
python main.py -s komiku -q "martial peak" -d "1,2,3"

# Download chapter range
python main.py -s komiku -q "martial peak" -d "1-10"

# Custom output directory
python main.py -s komiku -q "martial peak" -d all -o my_comics

# softkomik.co
python main.py -s softkomik -q "solo leveling" -d all
```

## 📋 Supported Sites

| Site | Status | Cloudflare |
|------|--------|------------|
| komiku.org | ✅ Working | No |
| komikindo.ch | ⚠️ Partial | Yes (needs cloudscraper) |
| softkomik.co | ✅ Working | No |

## 📁 Output Structure

### Info JSON Format

```json
{
  "title": "Martial Peak",
  "genres": ["Action", "Adventure", "Fantasy"],
  "synopsis": "Bercerita tentang...",
  "info": {
    "Judul": "Martial Peak",
    "Tipe": "Manhua",
    "Status": "Ongoing",
    "Author": "Momo"
  },
  "source": "komiku.org",
  "url": "https://komiku.org/manga/martial-peak/"
}
```

## ⚠️ Notes

- Gunakan tool ini dengan bijak
- Hormati hak cipta creator
- Jangan download terlalu cepat (ada delay antar chapter)
- komikindo.ch membutuhkan `cloudscraper` untuk bypass Cloudflare
- softkomik.co butuh token sesi (`X-Token`/`X-Sign`) dari `/api/session/*` untuk
  mengambil daftar chapter dan daftar gambar; token diambil otomatis dan
  di-cache oleh scraper. Detail endpoint ada di komentar `scraper/softkomik.py`.
- Gambar softkomik.co pakai "trap image": kalau URL gambarnya tidak diberi
  `?id=...` atau permintaannya tidak membawa header `Referer` dari situsnya,
  CDN-nya tidak memberi error tapi mengalihkan ke `/baca-image.jpeg` (gambar
  promosi berukuran besar). Scraper sudah mengirim keduanya dan memeriksa
  hasilnya, jadi kalau situsnya mengganti kunci `id` itu, chapter yang gambarnya
  kena jebakan akan DILEWAT (tidak ditulis ke CBZ) dan ada peringatannya di
  terminal -- bukan diam-diam tersimpan sebagai halaman palsu.
- Koneksi softkomik.co bisa berubah sendiri di mesin yang dipakai bergantian
  (codespace/container di-restart, jaringan pindah, IP publik ganti). Cookie
  situs dan token sesinya terikat ke koneksi itu, jadi begitu ada permintaan
  yang gagal, scraper **membangun ulang sesinya otomatis** (beranda dikunjungi
  lagi, token dibuang lalu diambil lagi) sebelum menyerah. Kalau tetap gagal,
  penyebabnya ditulis di layar -- bukan lagi dilaporkan sebagai
  "Tidak ditemukan hasil!" yang bikin kelihatan situsnya rusak.
- Buat memastikan ini soal koneksi/sesi atau soal judulnya, jalankan dari
  folder `sc/`:
  ```bash
  python3 -m scraper.softkomik
  ```
  Outputnya: umur cookie login, status login, akses beranda, percobaan
  pencarian, dan apakah token sesi (beserta `contentAccess`) bisa diambil.
- Judul softkomik.co bertag Ecchi/Mature (kategori SENSITIVE) gambarnya dikunci
  situsnya sampai login. Saat itu kejadian, scraper menanyakan email+password di
  terminal **sekali**, lalu menyimpan cookie sesinya ke `sc/.softkomik-cookies.json`
  sehingga jalan berikutnya tidak ditanya lagi. Untuk mesin tanpa terminal
  (cron/SSH non-interaktif), set `SOFTKOMIK_EMAIL` dan `SOFTKOMIK_PASSWORD`.
  Password tidak pernah disimpan — hanya cookie. Hapus file cookie itu kalau
  ingin login ulang dengan akun lain.

## 🔧 Requirements

- Python 3.8+
- requests
- beautifulsoup4
- cloudscraper (untuk komikindo.ch)
- rich (untuk terminal UI)
