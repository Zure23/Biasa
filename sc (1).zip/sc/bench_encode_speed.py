#!/usr/bin/env python3
"""Benchmark kecepatan + efisiensi encode 1 halaman (500x1736).

Varian:
  1. scraper      : Pillow + pillow-avif-plugin (libavif+aom), q40, speed 8   [yang dipakai sekarang]
  2. plugin svt   : pillow-avif-plugin codec="svt" (SVT-AV1 v4.1.0)
  3. ffmpeg svt   : ffmpeg libsvtav1 preset 5 (SVT-AV1 v1.7.0), range full
  4. avifenc svt  : avifenc -c svt -s 5 (SVT-AV1 v1.7.0) -> catatan: tag range salah
"""
import io
import re
import statistics
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from PIL import Image
import pillow_avif  # noqa: F401
from scraper import KomikuScraper

HERE = Path(__file__).resolve().parent
PAGE = HERE / "bench_page_compare" / "page_w500.png"
OUT = HERE / "bench_page_compare" / "_enc"
OUT.mkdir(parents=True, exist_ok=True)
REPEAT = 3


def ssim(a, b):
    ref = OUT / f"ref_{Path(a).stem}.png"
    subprocess.run(["avifdec", str(a), str(ref), "-q", "100"], capture_output=True)
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(ref if ref.exists() else a), "-i", str(b),
                        "-lavfi", "ssim", "-f", "null", "-"], capture_output=True, text=True)
    m = re.search(r"All:([0-9.]+)", r.stderr or "")
    return float(m.group(1)) if m else float("nan")


def timeit(fn, repeat=REPEAT):
    ts = []
    for _ in range(repeat):
        t = time.perf_counter()
        fn()
        ts.append(time.perf_counter() - t)
    return statistics.median(ts), min(ts)


im = Image.open(PAGE).convert("RGB")
sc = KomikuScraper(str(HERE / "bench_page_compare"))
print(f"halaman: {im.width}x{im.height} ({im.width*im.height/1e6:.3f} MP) | cpu: 2 core\n")
print(f"{'varian':26} {'detik/encode':>13} {'size':>9} {'SSIM':>7} {'kB/s':>8}")

rows = []

# 1. scraper (aom speed 8, quality 40)
out1 = OUT / "scraper_aom_q40.avif"


def r1():
    out1.write_bytes(sc._encode_avif(im))


med, mn = timeit(r1)
rows.append(("scraper (aom s8 q40)", med, out1.stat().st_size, ssim(out1, PAGE)))

# 2. plugin libavif codec=svt (SVT-AV1 v4.1.0)
for sp, q in [(5, 40), (6, 40), (8, 40)]:
    o = OUT / f"plugin_svt_s{sp}_q{q}.avif"

    def r2(o=o, sp=sp, q=q):
        buf = io.BytesIO()
        im.save(buf, "AVIF", codec="svt", speed=sp, quality=q)
        o.write_bytes(buf.getvalue())

    med, mn = timeit(r2)
    rows.append((f"plugin svt s{sp} q{q}", med, o.stat().st_size, ssim(o, PAGE)))

# 3. ffmpeg libsvtav1 preset 5 (SVT v1.7.0)
for crf in [44]:
    o = OUT / f"ffmpeg_svt_crf{crf}.avif"

    def r3(o=o, crf=crf):
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(PAGE),
                        "-vf", "scale=in_range=full:out_range=full", "-frames:v", "1",
                        "-c:v", "libsvtav1", "-crf", str(crf), "-preset", "5",
                        "-pix_fmt", "yuv420p", "-color_range", "pc", str(o)], check=True)

    med, mn = timeit(r3)
    rows.append((f"ffmpeg svt preset5 crf{crf}", med, o.stat().st_size, ssim(o, PAGE)))

# 4. avifenc svt s5
o = OUT / "avifenc_svt_s5_q30.avif"


def r4():
    subprocess.run(["avifenc", "-c", "svt", "-s", "5", "-q", "30", "--yuv", "420",
                    str(PAGE), str(o)], capture_output=True)


med, mn = timeit(r4)
rows.append(("avifenc svt s5 q30", med, o.stat().st_size, ssim(o, PAGE)))

for name, med, size, v in rows:
    print(f"{name:26} {med:>13.2f} {size:>9,} {v:>7.4f} {size/1024/med:>8.1f}")
