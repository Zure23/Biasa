#!/usr/bin/env python3
"""
Benchmark per-gambar: AVIF dari SCRAPER vs AVIF dari SVT-AV1 (avifenc).

Aturan:
- Scraper ASLI tidak diubah sama sekali (cuma di-import).
- Gambar ORIGINAL diambil dengan cara scraper: search -> get_manga_detail ->
  get_chapter_images_ordered -> _download_image_with_retry.
- Sisi "scraper": Image -> _prepare_image (w500, no crop) -> _encode_avif
  (Pillow + pillow-avif-plugin, quality 40, speed 8) = method asli scraper.
- Sisi "svt"    : PNG w500 yang sama (dipad 1px kalau tinggi ganjil, syarat SVT)
  -> avifenc -c svt -s 5 -q 40 --yuv 420 -a tune=4.

Output: ukuran per file + total + SSIM tiap sisi vs gambar w500 (kualitas).

Pakai:
    python3 bench_orig_vs_svt.py --chapter 1
"""
import io
import os
import re
import sys
import shutil
import argparse
import subprocess
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PIL import Image
import pillow_avif  # noqa: F401

from scraper import KomikuScraper  # scraper asli, TIDAK diubah

MANGA_URL = "https://komiku.org/manga/my-sister-is-a-superstar/"
SVT_SPEED = "5"
SVT_TUNE = "4"
QUALITY = 40
BASE_DIR = Path(__file__).resolve().parent / "bench_orig_compare"


def sh(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def ssim(a: Path, b: Path) -> float:
    r = sh(["ffmpeg", "-hide_banner", "-i", str(a), "-i", str(b),
            "-lavfi", "ssim", "-f", "null", "-"])
    for line in (r.stderr or "").splitlines():
        if "SSIM" in line and "All:" in line:
            try:
                return float(line.split("All:")[1].split()[0].split("(")[0])
            except Exception:
                return float("nan")
    return float("nan")


def even_pad(im: Image.Image) -> Image.Image:
    """Tambah 1 baris/kolom hitam kalau dimensi ganjil (syarat SVT 4:2:0)."""
    w, h = im.size
    ew, eh = w + (w & 1), h + (h & 1)
    if (ew, eh) == (w, h):
        return im
    canvas = Image.new("RGB", (ew, eh), (0, 0, 0))
    canvas.paste(im, (0, 0))
    return canvas


def pick_chapter(scraper, chapter_no: int):
    detail = scraper.get_manga_detail(MANGA_URL)
    if not detail:
        raise SystemExit("gagal ambil detail manga")
    for ch in detail["chapters"]:
        m = re.search(r"(\d+(?:\.\d+)?)", ch["title"])
        if m and abs(float(m.group(1)) - chapter_no) < 1e-6:
            return detail, ch
    raise SystemExit(f"chapter {chapter_no} tidak ketemu (total {len(detail['chapters'])})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--chapter", type=int, default=1)
    args = ap.parse_args()

    d_orig = BASE_DIR / "original"
    d_scraper = BASE_DIR / "avif_scraper"
    d_svt = BASE_DIR / "avif_svt"
    d_prep = BASE_DIR / "prepared_png"
    for d in (d_orig, d_scraper, d_svt, d_prep):
        if d.exists():
            shutil.rmtree(d)
        d.mkdir(parents=True, exist_ok=True)

    scraper = KomikuScraper(str(BASE_DIR))
    print(f"🔎 Cari chapter {args.chapter} ...")
    detail, chapter = pick_chapter(scraper, args.chapter)
    print(f"   {detail['title']} -> {chapter['title']}")
    print(f"   {chapter['url']}")

    imgs = scraper.get_chapter_images_ordered(chapter["url"])
    if not imgs:
        raise SystemExit("tidak ada gambar")
    print(f"   {len(imgs)} gambar original\n")

    print("⬇️  Ambil gambar ORIGINAL (cara scraper) + siapkan w500 ...")
    rows = []
    for i, item in enumerate(imgs, 1):
        data = scraper._download_image_with_retry(item["url"])
        if not data:
            print(f"   ⚠️  gambar {i} gagal download, dilewati")
            continue
        ext = scraper._detect_image_ext(data)
        (d_orig / f"{i:03d}{ext}").write_bytes(data)

        im = scraper._prepare_image(Image.open(io.BytesIO(data)))  # asli scraper
        png = d_prep / f"{i:03d}.png"
        im.save(png)
        png_even = d_prep / f"{i:03d}_even.png"
        even_pad(im).save(png_even)
        rows.append({"i": i, "ext": ext, "orig": len(data), "png": png,
                     "png_even": png_even, "scraper": None, "scraper_ssim": None,
                     "svt": None, "svt_ssim": None, "srcdim": im.size})
        print(f"   [{i}/{len(imgs)}] {item['url'].split('/')[-1]} -> {im.width}x{im.height}")

    print("\n🧩 Encode sisi SCRAPER (Pillow/libaom, w500 q40) ...")
    for r in rows:
        avif = scraper._encode_avif(Image.open(r["png"]))  # inti encoder scraper
        if not avif:
            continue
        out = d_scraper / f"{r['i']:03d}.avif"
        out.write_bytes(avif)
        r["scraper"] = len(avif)
        r["scraper_ssim"] = ssim(out, r["png"])

    print(f"\n⚡ Encode sisi SVT-AV1 (avifenc -c svt -s {SVT_SPEED} -q {QUALITY} --yuv 420 -a tune={SVT_TUNE}) ...")
    for r in rows:
        out = d_svt / f"{r['i']:03d}.avif"
        base = ["avifenc", "-c", "svt", "-s", SVT_SPEED, "-q", str(QUALITY),
                "--yuv", "420"]
        res = sh(base + ["-a", f"tune={SVT_TUNE}", str(r["png_even"]), str(out)])
        if not out.exists():
            res = sh(base + [str(r["png_even"]), str(out)])  # fallback tanpa tune
        if not out.exists():
            print(f"   ⚠️  avifenc gagal {r['i']}: {res.stderr[-160:]}")
            continue
        r["svt"] = out.stat().st_size
        r["svt_ssim"] = ssim(out, r["png_even"])

    ok = [r for r in rows if r["scraper"] and r["svt"]]
    print("\n" + "=" * 84)
    print(f"{'#':>3} {'ori(B)':>8} {'scraper(B)':>10} {'svt(B)':>9} {'selisih':>9} {'svt vs scraper':>14}  {'SSIM s/svt':>15}")
    print("-" * 84)
    tot_o = sum(r["orig"] for r in ok)
    tot_s = sum(r["scraper"] for r in ok)
    tot_v = sum(r["svt"] for r in ok)
    for r in ok:
        pct = (r["svt"] - r["scraper"]) / r["scraper"] * 100
        print(f"{r['i']:>3} {r['orig']:>8} {r['scraper']:>10} {r['svt']:>9} "
              f"{r['svt']-r['scraper']:>+9} {pct:>+13.1f}%  {r['scraper_ssim']:.4f}/{r['svt_ssim']:.4f}")
    print("-" * 84)

    n = len(ok)
    kb = lambda x: x / 1024
    print(f"\nGambar dibandingkan  : {n}")
    print(f"Total ORIGINAL       : {tot_o:>9} B  ({kb(tot_o):8.1f} KB, {kb(tot_o)/1024:.3f} MB)  avg {tot_o/max(n,1):.0f} B")
    print(f"Total AVIF scraper   : {tot_s:>9} B  ({kb(tot_s):8.1f} KB, {kb(tot_s)/1024:.3f} MB)  avg {tot_s/max(n,1):.0f} B")
    print(f"Total AVIF SVT       : {tot_v:>9} B  ({kb(tot_v):8.1f} KB, {kb(tot_v)/1024:.3f} MB)  avg {tot_v/max(n,1):.0f} B")
    if tot_s:
        d = tot_v - tot_s
        tag = "HEMAT" if d < 0 else "RUGI"
        print(f"Selisih SVT vs scraper: {d:>+9} B  -> {tag} {abs(d)/tot_s*100:.2f}% (relatif ke scraper)")
    s_ssim = [r["scraper_ssim"] for r in ok if r["scraper_ssim"] == r["scraper_ssim"]]
    v_ssim = [r["svt_ssim"] for r in ok if r["svt_ssim"] == r["svt_ssim"]]
    if s_ssim:
        print(f"Rata-rata SSIM scraper : {sum(s_ssim)/len(s_ssim):.4f}")
    if v_ssim:
        print(f"Rata-rata SSIM SVT     : {sum(v_ssim)/len(v_ssim):.4f}")
    print(f"\n📁 Hasil: {BASE_DIR}")


if __name__ == "__main__":
    main()
