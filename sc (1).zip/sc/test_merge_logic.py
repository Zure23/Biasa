#!/usr/bin/env python3
"""
Test logika MERGE gambar scraper (bagi grup + tumpuk vertikal).

Fokus use case jumlah gambar per chapter: < 10, pas 10, ganjil, belasan,
puluhan, ratusan. Yang divalidasi:
  - jumlah file hasil = min(N, 10) -> "mau berapa pun gambar sumbernya"
  - nggak ada gambar hilang / dobel / kepotong (merge, BUKAN crop)
  - urutan baca tetap atas -> bawah
  - chapter pendek (< 10 gambar) nggak dipaksa jadi 10 (nggak ada duplikat/slot kosong)

Jalankan: python test_merge_logic.py   (atau pytest test_merge_logic.py)
"""
import io
import zipfile
import tempfile
from pathlib import Path

from PIL import Image

import pillow_avif  # noqa: F401  (register AVIF plugin)
from scraper.base import BaseScraper

TARGET = 10


class _DummyScraper(BaseScraper):
    """Scraper kosong buat nge-test helper merge tanpa network."""

    def search(self, query):
        return []

    def get_manga_detail(self, url):
        return None

    def get_chapter_images_ordered(self, url):
        return []


def _scraper() -> _DummyScraper:
    tmp = tempfile.mkdtemp(prefix="test_merge_")
    return _DummyScraper(str(tmp))


def _png(color, size) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, "PNG")
    return buf.getvalue()


def _near(actual, expected, tol=35) -> bool:
    """AVIF itu lossy, jadi warna dicek pakai toleransi."""
    if isinstance(actual, int):
        return abs(actual - expected) <= tol
    return all(abs(a - e) <= tol for a, e in zip(actual, expected))


# ---------------------------------------------------------------- grouping ---
def test_group_plan_never_loses_or_duplicates_images():
    for n in list(range(1, 31)) + [49, 90, 100, 107]:
        items = list(range(n))
        groups = BaseScraper.split_into_merge_groups(items, TARGET)

        assert len(groups) == min(n, TARGET), f"n={n}"
        assert all(len(g) > 0 for g in groups), f"ada grup kosong di n={n}"
        assert [x for g in groups for x in g] == items, f"urutan/isi berubah di n={n}"

        sizes = [len(g) for g in groups]
        assert max(sizes) - min(sizes) <= 1, f"grup nggak rata di n={n}: {sizes}"

    print("✓ pembagian grup: nggak ada gambar hilang/dobel, jumlah file = min(N, 10)")


def test_group_plan_examples():
    def sizes(n):
        return [len(g) for g in BaseScraper.split_into_merge_groups(list(range(n)), TARGET)]

    assert sizes(1) == [1]
    assert sizes(3) == [1, 1, 1]                       # kurang dari 10: ya udah, 3 file
    assert sizes(7) == [1] * 7                         # nggak bisa dipaksa 10 tanpa duplikat
    assert sizes(9) == [1] * 9
    assert sizes(10) == [1] * 10                       # pas 10: tiap gambar file sendiri
    assert sizes(11) == [2] + [1] * 9                  # belasan ganjil: 1 grup isi 2
    assert sizes(15) == [2] * 5 + [1] * 5
    assert sizes(19) == [2] * 9 + [1]
    assert sizes(20) == [2] * 10
    assert sizes(21) == [3, 2, 2, 2, 2, 2, 2, 2, 2, 2]
    assert sizes(90) == [9] * 10
    assert sizes(107) == [11] * 7 + [10] * 3
    assert sum(sizes(107)) == 107

    # merge dimatikan (target <= 1) -> tiap gambar file sendiri
    assert [len(g) for g in BaseScraper.split_into_merge_groups(list(range(5)), 1)] == [1] * 5

    print("✓ use case jumlah gambar: <10, pas 10, ganjil, belasan, puluhan, ratusan")


# ------------------------------------------------------------------- merge ---
def test_merge_stacks_vertically_without_crop():
    sc = _scraper()
    colors = [(255, 0, 0), (0, 200, 0), (0, 0, 255), (230, 230, 0)]
    heights = [100, 130, 90, 160]
    imgs = [_png(colors[i], (500, heights[i])) for i in range(4)]

    out = sc._merge_group_to_avif(imgs)
    assert out, "merge gagal"

    merged = Image.open(io.BytesIO(out))
    assert merged.size == (500, sum(heights)), \
        f"tinggi/lebar berubah: {merged.size} != (500, {sum(heights)})"

    # tiap halaman harus masih utuh, urut atas -> bawah
    y = 0
    for i in range(4):
        mid = merged.getpixel((250, y + heights[i] // 2))
        assert _near(mid, colors[i]), f"halaman {i} nggak sesuai warna aslinya: {mid}"
        y += heights[i]

    print("✓ merge tumpuk vertikal: semua halaman utuh + urutan tetap (bukan crop)")


def test_merge_handles_different_widths_without_crop():
    sc = _scraper()
    small = _png((255, 0, 0), (300, 100))     # lebih sempit dari w500, jangan di-upscale
    wide = _png((0, 0, 255), (800, 120))      # lebih lebar dari w500 -> di-resize ke 500

    out = sc._merge_group_to_avif([small, wide])
    merged = Image.open(io.BytesIO(out))

    assert merged.width == 500, f"lebar canvas harus 500, dapat {merged.width}"
    assert merged.height == 100 + 75, f"tinggi total harus 175, dapat {merged.height}"  # 800x120 -> 500x75

    top = merged.getpixel((250, 50))
    bottom = merged.getpixel((250, 130))
    assert _near(top, (255, 0, 0)), f"halaman atas berubah: {top}"
    assert _near(bottom, (0, 0, 255)), f"halaman bawah berubah: {bottom}"

    print("✓ lebar beda: disamakan ke w500, tinggi total tetap, nggak ada yang kepotong")


def test_single_image_group_is_just_converted():
    sc = _scraper()
    out = sc._merge_group_to_avif([_png((0, 128, 0), (640, 200))])
    merged = Image.open(io.BytesIO(out))
    assert merged.size == (500, 156), f"dapat {merged.size}"  # 640x200 -> 500x156
    print("✓ grup 1 gambar: langsung convert, ukuran tetap w500")


class _QuietProgress:
    """ProgressTracker tanpa spam print; kalau chapter gagal -> test gagal."""

    def start_chapter(self, *a, **k):
        pass

    def update_chapter(self, *a, **k):
        pass

    def complete_chapter(self, *a, **k):
        pass

    def fail_chapter(self, chapter, reason):
        raise AssertionError(f"chapter gagal diproses: {reason}")

    def skip_chapter(self, *a, **k):
        pass

    def summary(self):
        pass


def _fake_scraper(n_images):
    """Scraper palsu: n gambar warna beda + tinggi beda, tanpa network."""
    sc = _scraper()
    colors = [((i * 37) % 256, (i * 91) % 256, (i * 53) % 256) for i in range(n_images)]
    heights = [120 + (i % 5) * 10 for i in range(n_images)]
    ordered = [{'order': i + 1, 'url': f'fake://img/{i + 1}'} for i in range(n_images)]
    blob = {f'fake://img/{i + 1}': _png(colors[i], (500, heights[i]))
            for i in range(n_images)}

    sc.get_chapter_images_ordered = lambda url: ordered
    sc._download_image_with_retry = lambda url: blob[url]
    return sc, colors, heights


def test_process_chapter_end_to_end_merge_and_order():
    """Pipeline asli: download -> merge -> AVIF -> CBZ, cek jumlah file + urutan baca."""
    for n in (3, 11, 25, 49):
        sc, colors, heights = _fake_scraper(n)
        folder = Path(sc.download_dir)
        chapter = {'title': f'Chapter {n}', 'url': 'fake://chapter'}

        ok = sc._process_chapter(chapter, folder, _QuietProgress())
        assert ok, f"_process_chapter gagal di n={n}"

        cbz = folder / f"chapter-{str(n).zfill(3)}.cbz"
        assert cbz.exists(), f"CBZ nggak dibuat di n={n}"

        with zipfile.ZipFile(cbz) as zf:
            names = sorted(zf.namelist())
            assert len(names) == min(n, TARGET), f"jumlah file n={n}: {len(names)}"
            assert names == [f"{i:03d}.avif" for i in range(1, len(names) + 1)]

            # Susuri tiap strip: warna band harus persis urutan gambar sumber
            src = 0
            for name in names:
                im = Image.open(io.BytesIO(zf.read(name)))
                y = 0
                while y < im.height:
                    h = heights[src]
                    assert y + h <= im.height, f"halaman kepotong di n={n}, {name}"
                    mid = im.getpixel((250, y + h // 2))
                    assert _near(mid, colors[src]), \
                        f"urutan salah di n={n}, {name}, halaman {src}: {mid} != {colors[src]}"
                    y += h
                    src += 1
                assert y == im.height, f"tinggi strip nggak pas di n={n}, {name}"

            assert src == n, f"ada halaman hilang di n={n}: {src}/{n}"

    print("✓ pipeline _process_chapter: N gambar -> min(N,10) AVIF di CBZ, urutan utuh")


def test_oversized_strip_returns_none_so_pages_are_not_lost():
    sc = _scraper()
    sc.MAX_STRIP_HEIGHT = 150      # paksa strip 'kepanjangan' buat libavif
    imgs = [_png((10, 10, 10), (500, 100)) for _ in range(4)]

    assert sc._merge_group_to_avif(imgs) is None, "guard MAX_STRIP_HEIGHT nggak jalan"
    # Tapi halamannya harus tetap bisa diselamatkan satu-satu (fallback _process_chapter)
    assert all(sc._convert_to_avif(im) for im in imgs)

    print("✓ strip kepanjangan: merge di-skip, halaman tetap disimpan terpisah (nggak hilang)")


if __name__ == "__main__":
    test_group_plan_never_loses_or_duplicates_images()
    test_group_plan_examples()
    test_merge_stacks_vertically_without_crop()
    test_merge_handles_different_widths_without_crop()
    test_single_image_group_is_just_converted()
    test_process_chapter_end_to_end_merge_and_order()
    test_oversized_strip_returns_none_so_pages_are_not_lost()
    print("\n✅ SEMUA TEST LULUS")
