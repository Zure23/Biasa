"""
Base scraper with 10 parallel workers + Progress UI + Validation
"""
import os
import re
import json
import time
import io
import zipfile

# Senyapkan log SVT-AV1 (banner versi + info/warn dicetak ke stderr tiap encode,
# bikin progress UI penuh). HARUS diset sebelum pillow_avif diimpor: nilainya
# dibaca sekali saja saat pertama kali encoder dipakai, jadi mengubahnya setelah
# encode pertama tidak berpengaruh. Level: 0 senyap total, 1 = error saja (dipakai),
# 2 = warning, 3+ = info lengkap. Mau lihat log penuh? `SVT_LOG=3 python3 main.py`.
os.environ.setdefault("SVT_LOG", "1")

import requests
import pillow_avif
from urllib.parse import urlsplit
from PIL import Image
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock, Event, BoundedSemaphore


# komikindo (WordPress) nyimpen thumbnail sebagai "namafile-223x319.jpg".
# Buang suffix ukuran itu buat nembak file aslinya (kualitas penuh).
WP_THUMB_SIZE_RE = re.compile(
    r'-\d{2,4}x\d{2,4}(?=\.(?:jpe?g|png|webp|gif|avif|bmp)(?:$|\?))', re.IGNORECASE)
SIZE_PARAM_NAMES = {'w', 'h', 'resize', 'width', 'height', 'q', 'quality'}


class ProgressTracker:
    """Track and display download progress"""
    
    def __init__(self, total_chapters: int):
        self.total = total_chapters
        self.completed = 0
        self.failed = 0
        self.skipped = 0
        self.in_progress = {}
        self._lock = Lock()
        self.start_time = time.time()
        self.results = []  # Track all results
    
    def start_chapter(self, chapter: str, worker_id: int = 0):
        with self._lock:
            self.in_progress[chapter] = {
                'start': time.time(),
                'worker': worker_id
            }
            self._print_status()
    
    def update_chapter(self, chapter: str, message: str):
        with self._lock:
            if chapter in self.in_progress:
                elapsed = time.time() - self.in_progress[chapter]['start']
                worker = self.in_progress[chapter]['worker']
                print(f"\r  [Worker-{worker}] {chapter}: {message} ({elapsed:.1f}s)", end="", flush=True)
    
    def complete_chapter(self, chapter: str, size_kb: float, images: int = 0):
        with self._lock:
            self.completed += 1
            worker = self.in_progress.get(chapter, {}).get('worker', 0)
            elapsed = 0
            if chapter in self.in_progress:
                elapsed = time.time() - self.in_progress[chapter]['start']
                del self.in_progress[chapter]
            
            self.results.append({
                'chapter': chapter,
                'status': 'success',
                'size_kb': size_kb,
                'images': images,
                'time': elapsed
            })
            self._print_status(f"✅ {chapter} ({size_kb:.0f} KB, {images} imgs, {elapsed:.1f}s)")
    
    def fail_chapter(self, chapter: str, reason: str):
        with self._lock:
            self.failed += 1
            worker = self.in_progress.get(chapter, {}).get('worker', 0)
            if chapter in self.in_progress:
                del self.in_progress[chapter]
            
            self.results.append({
                'chapter': chapter,
                'status': 'failed',
                'reason': reason
            })
            self._print_status(f"❌ {chapter}: {reason}")
    
    def skip_chapter(self, chapter: str):
        with self._lock:
            self.skipped += 1
            self.results.append({
                'chapter': chapter,
                'status': 'skipped'
            })
            self._print_status(f"⏭️  {chapter} (sudah ada)")
    
    def _print_status(self, message: str = ""):
        elapsed = time.time() - self.start_time
        done = self.completed + self.failed + self.skipped
        active = len(self.in_progress)
        
        # Progress bar
        pct = (done / self.total * 100) if self.total > 0 else 0
        bar_len = 30
        filled = int(bar_len * done / self.total) if self.total > 0 else 0
        bar = "█" * filled + "░" * (bar_len - filled)
        
        status_line = f"\r  [{bar}] {pct:.0f}% | ✓{self.completed} ✗{self.failed} ○{self.skipped} ⏳{active} | {elapsed:.0f}s"
        print(status_line, end="", flush=True)
        
        if message:
            print(f"\n  {message}")
    
    def summary(self):
        elapsed = time.time() - self.start_time
        print(f"\n{'='*60}")
        print(f"  ✅ SELESAI | {self.completed}/{self.total} success | {self.failed} failed | {self.skipped} skipped | {elapsed:.1f}s")
        
        if self.results:
            total_size = sum(r.get('size_kb', 0) for r in self.results if r['status'] == 'success')
            total_images = sum(r.get('images', 0) for r in self.results if r['status'] == 'success')
            print(f"  📊 Total: {total_size:.0f} KB | {total_images} images")
        
        print(f"{'='*60}")


class BaseScraper(ABC):
    """Base class with 10 parallel workers + validation"""
    
    BASE_URL = ""
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    }
    
    DEFAULT_WIDTH = 500
    # --- Encoder AVIF: satu setelan saja (preset kualitas dihapus) ---
    # SVT-AV1 lewat pillow-avif-plugin, speed 5, tune 1 (PSNR = default SVT), crf 43.
    # Diukur di strip merge 4 halaman (500x5645): 49.668 B / SSIM 0.9774, ~10% lebih
    # kecil dari jalur libaom lama pada kualitas setara.
    AVIF_CODEC = 'svt'
    AVIF_SPEED = 5
    AVIF_TUNE = 1
    AVIF_CRF = 43
    # Nilai quality libavif: cuma cadangan; yang menentukan hasil = AVIF_CRF di atas
    # (crf menimpa quality di jalur libavif).
    DEFAULT_QUALITY = 40
    # Hasil encode selalu divalidasi; kalau tidak valid diulang sampai batas ini supaya
    # tidak ada AVIF kosong/terpotong yang masuk CBZ.
    AVIF_ENCODE_ATTEMPTS = 5
    AVIF_RETRY_DELAY = 0.5
    # Batas keras SVT-AV1: tinggi sumber maksimal 8704 px ("Source Height must be
    # less than or equal to 8704"). Strip hasil merge bisa jauh lebih tinggi, jadi
    # gambar setinggi itu langsung di-encode libaom -- tanpa mencoba SVT yang cuma
    # menghasilkan error berulang.
    AVIF_MAX_HEIGHT = 8704
    MERGE_TARGET_COUNT = 10    # 1 chapter di-merge jadi maksimal 10 gambar (<=1 = nonaktif)
    # Margin aman tinggi strip saat membagi grup merge (lihat split_into_merge_groups_by_height).
    MERGE_HEIGHT_MARGIN = 16
    MAX_STRIP_HEIGHT = 60000   # batas aman tinggi strip AVIF (libavif mentok di 65536)
    MAX_WORKERS = 10
    CONVERT_CONCURRENCY = 2   # CPU 2 core -> maks 2 convert AVIF jalan bareng
    INNER_DOWNLOAD_WORKERS = 3  # download gambar paralel di dalam 1 chapter
    MAX_RETRIES = 3
    RETRY_DELAY = 1
    
    def __init__(self, download_dir: str = "downloads"):
        self.download_dir = Path(download_dir)
        self.download_dir.mkdir(parents=True, exist_ok=True)
        self.session = self._create_session()
        # Semaphore global: batasi convert AVIF (CPU-bound) sesuai jumlah core
        self._convert_sem = BoundedSemaphore(self.CONVERT_CONCURRENCY)
    
    def _create_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update(self.HEADERS)
        return session
    
    def _get_page(self, url: str) -> Optional[str]:
        for attempt in range(self.MAX_RETRIES):
            try:
                resp = self.session.get(url, timeout=60)
                resp.raise_for_status()
                return resp.text
            except Exception as e:
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY * (attempt + 1))
                else:
                    return None
    
    def _download_image_with_retry(self, url: str) -> Optional[bytes]:
        """Download image with retry"""
        for attempt in range(self.MAX_RETRIES):
            try:
                resp = self.session.get(url, timeout=30)
                resp.raise_for_status()
                data = resp.content
                # Validate image data
                if len(data) < 1000:  # Too small, likely error
                    raise Exception("Image data too small")
                return data
            except Exception as e:
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY)
        return None
    
    def _sanitize_filename(self, name: str) -> str:
        name = re.sub(r'[<>:"/\\|?*]', '', name)
        return name.strip().replace(' ', '_')[:200]
    
    def _upgrade_image_url(self, url: str) -> str:
        """Naikin resolusi URL gambar:
        - buang suffix ukuran WordPress (-223x319) -> balik ke file asli
        - samain skema URL relatif/protocol-relative (//cdn -> https://cdn)
        """
        if not url:
            return ''
        url = url.strip()
        if url.startswith('//'):
            url = 'https:' + url
        elif url.startswith('/'):
            url = f"{self.BASE_URL}{url}"
        return WP_THUMB_SIZE_RE.sub('', url)
    
    @staticmethod
    def _strip_size_param(url: str) -> str:
        """Buang parameter ukuran (?w=500, ?resize=300,180, ?q=...) biar file asli."""
        if not url or '?' not in url:
            return url or ''
        base, _, query = url.partition('?')
        keep = [kv for kv in query.split('&')
                if kv and kv.split('=')[0].lower() not in SIZE_PARAM_NAMES]
        return base + ('?' + '&'.join(keep) if keep else '')
    
    @staticmethod
    def _dedupe_urls(urls: List[str]) -> List[str]:
        """Buang URL kosong & duplikat, urutan dipertahankan."""
        out = []
        for u in urls:
            u = (u or '').strip()
            if u and u not in out:
                out.append(u)
        return out
    
    def _is_placeholder_url(self, url: str) -> bool:
        """Deteksi gambar placeholder/lazy (bukan cover beneran)."""
        u = (url or '').lower()
        if not u or u.startswith('data:'):
            return True
        return 'lazy.jpg' in u or 'placeholder' in u or '/blank.' in u or u.endswith('spacer.gif')
    
    def _cover_candidates_from_img(self, img) -> List[str]:
        """Kumpulin kandidat URL cover dari 1 tag <img>, kualitas tinggi dulu.
        Lazy-load attr (data-lazy-src/data-src) biasanya file asli, `src` sering
        thumbnail kecil. Tiap kandidat juga dimasukin versi 'diupgrade' (tanpa
        suffix ukuran WordPress) di depan.
        """
        raw = []
        if img is not None:
            for attr in ('data-lazy-src', 'data-src', 'data-original', 'src'):
                val = img.get(attr)
                if val:
                    raw.append(val)
            srcset = img.get('srcset') or img.get('data-srcset')
            if srcset:
                raw.append(self._largest_from_srcset(srcset))
        
        out = []
        for u in raw:
            for candidate in (self._upgrade_image_url(u), u):
                candidate = (candidate or '').strip()
                if candidate and candidate not in out and not self._is_placeholder_url(candidate):
                    out.append(candidate)
        return out
    
    def _largest_from_srcset(self, srcset: str) -> str:
        """Ambil URL paling gede dari atribut srcset (pakai descriptor w/x)."""
        best, best_score = '', -1
        for part in (srcset or '').split(','):
            bits = part.strip().split()
            if not bits:
                continue
            score = 0
            if len(bits) > 1:
                try:
                    if bits[1].endswith('w'):
                        score = int(bits[1][:-1])
                    elif bits[1].endswith('x'):
                        score = int(float(bits[1][:-1]) * 100000)
                except ValueError:
                    score = 0
            if score > best_score:
                best, best_score = bits[0], score
        return best
    
    def _detect_image_ext(self, data: bytes, content_type: str = '') -> str:
        """Detect image extension from magic bytes (fallback: Content-Type)."""
        if data[:8] == b'\x89PNG\r\n\x1a\n':
            return '.png'
        if data[:3] == b'\xff\xd8\xff':
            return '.jpg'
        if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
            return '.webp'
        if data[:6] in (b'GIF87a', b'GIF89a'):
            return '.gif'
        if data[:2] == b'BM':
            return '.bmp'
        # Fallback ke Content-Type
        if 'png' in content_type:
            return '.png'
        if 'webp' in content_type:
            return '.webp'
        if 'gif' in content_type:
            return '.gif'
        return '.jpg'
    
    def _save_info_json(self, info: Dict[str, Any], save_path: Path) -> None:
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(info, f, ensure_ascii=False, indent=2)
    
    def _prepare_image(self, image: Image.Image) -> Image.Image:
        """Flatten transparansi + resize ke lebar target (w500). Tanpa crop."""
        # Handle transparent images
        if image.mode in ('RGBA', 'LA', 'P'):
            background = Image.new('RGB', image.size, (255, 255, 255))
            if image.mode == 'P':
                image = image.convert('RGBA')
            background.paste(image, mask=image.split()[-1] if len(image.split()) > 3 else None)
            image = background
        elif image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Resize if too wide (aspect ratio dijaga, tinggi ngikut)
        if image.width > self.DEFAULT_WIDTH:
            ratio = self.DEFAULT_WIDTH / image.width
            new_height = max(1, int(image.height * ratio))
            image = image.resize((self.DEFAULT_WIDTH, new_height), Image.LANCZOS)
        return image
    
    def _avif_is_valid(self, data: bytes, source: Image.Image) -> bool:
        """Cek AVIF hasil encode benar-benar utuh & sesuai gambar sumber.
        
        Menangkap output kosong / terpotong / berubah ukuran -- inilah penyebab
        dulu ada AVIF buram di CBZ (encode gagal tapi hasilnya tetap dipakai).
        """
        if not data or len(data) < 100:
            return False
        try:
            with Image.open(io.BytesIO(data)) as check:
                if check.size != source.size:
                    return False
                small = check.convert('L').resize((32, 32))
        except Exception:
            return False
        
        vals = small.tobytes()
        mean = sum(vals) / len(vals)
        var = sum((v - mean) ** 2 for v in vals) / len(vals)
        
        src_small = source.convert('L').resize((32, 32))
        src_vals = src_small.tobytes()
        src_mean = sum(src_vals) / len(src_vals)
        src_var = sum((v - src_mean) ** 2 for v in src_vals) / len(src_vals)
        
        if src_var > 4 and var < 1:
            return False        # sumber ada isinya tapi hasil nyaris rata -> gambar hilang
        return abs(mean - src_mean) <= 25
    
    def _encode_avif_libaom(self, image: Image.Image) -> Optional[bytes]:
        """Jalur libaom (encoder lama). Dipakai untuk gambar yang tidak bisa lewat SVT
        (tinggi > AVIF_MAX_HEIGHT) atau kalau SVT gagal di semua percobaan."""
        try:
            buffer = io.BytesIO()
            image.save(buffer, "AVIF", codec='aom', quality=self.DEFAULT_QUALITY,
                       speed=self.AVIF_SPEED)
            result = buffer.getvalue()
            if self._avif_is_valid(result, image):
                return result
        except Exception:
            pass
        return None
    
    def _encode_avif(self, image: Image.Image) -> Optional[bytes]:
        """Encode PIL image -> AVIF (SVT tune 1, crf 43).
        
        Hasilnya divalidasi; kalau tidak valid (gagal/kosong/terpotong) encode
        DIULANG sampai AVIF_ENCODE_ATTEMPTS kali. Strip yang lebih tinggi dari batas
        SVT (AVIF_MAX_HEIGHT) atau yang tetap gagal setelah diulang, di-encode pakai
        libaom supaya halaman tidak pernah hilang kosong.
        """
        if image.height > self.AVIF_MAX_HEIGHT:
            return self._encode_avif_libaom(image)
        
        for attempt in range(self.AVIF_ENCODE_ATTEMPTS):
            try:
                buffer = io.BytesIO()
                image.save(buffer, "AVIF", codec=self.AVIF_CODEC,
                           quality=self.DEFAULT_QUALITY, speed=self.AVIF_SPEED,
                           advanced=[("tune", self.AVIF_TUNE), ("crf", self.AVIF_CRF)])
                result = buffer.getvalue()
                if self._avif_is_valid(result, image):
                    return result
            except Exception:
                pass
            if attempt < self.AVIF_ENCODE_ATTEMPTS - 1:
                time.sleep(self.AVIF_RETRY_DELAY)
        
        return self._encode_avif_libaom(image)
    
    def _convert_to_avif(self, image_data: bytes) -> Optional[bytes]:
        """Convert 1 gambar ke AVIF with validation"""
        try:
            image = self._prepare_image(Image.open(io.BytesIO(image_data)))
            return self._encode_avif(image)
        except Exception:
            return None
    
    def _merge_group_to_avif(self, images_data: List[bytes]) -> Optional[bytes]:
        """
        Gabung beberapa gambar jadi 1 strip VERTIKAL (halaman berurutan ditumpuk
        atas -> bawah, sesuai urutan baca), lalu encode AVIF.
        
        Ini MERGE, bukan crop: semua pixel dipertahankan. Lebar disamakan ke
        DEFAULT_WIDTH (aspect ratio dijaga), jadi tinggi strip = total tinggi semua
        halaman di grup. Return None kalau gagal (mis. strip kepanjangan buat AVIF)
        supaya caller bisa fallback per-gambar.
        """
        if not images_data:
            return None
        
        prepared = []
        for data in images_data:
            try:
                prepared.append(self._prepare_image(Image.open(io.BytesIO(data))))
            except Exception:
                continue
        
        if not prepared:
            return None
        if len(prepared) == 1:
            return self._encode_avif(prepared[0])
        
        width = max(im.width for im in prepared)
        height = sum(im.height for im in prepared)
        if height > self.MAX_STRIP_HEIGHT:
            return None
        
        strip = Image.new('RGB', (width, height), (255, 255, 255))
        y = 0
        for im in prepared:
            strip.paste(im, ((width - im.width) // 2, y))  # center, bukan crop
            y += im.height
        
        return self._encode_avif(strip)
    
    @staticmethod
    def split_into_merge_groups(images: List[Any], target: int = 10) -> List[List[Any]]:
        """
        Bagi sederet gambar (urut baca) jadi grup-grup yang nanti di-merge.
        
        Aturan (nggak ada gambar yang dipotong / dibuang / dobel):
        - total >= target  -> hasil PERSIS `target` grup, selisih jumlah antar grup
          maksimal 1 biar rata (contoh total=11, target=10 -> [2,1,1,1,1,1,1,1,1,1];
          total=19 -> [2,2,2,2,2,2,2,2,2,1]; total=90 -> 9 gambar/grup).
        - total < target   -> nggak mungkin 10 grup tanpa nambah gambar atau ngosongin
          slot, jadi tetap `total` grup (1 gambar/grup). Jumlah file < 10 itu wajar
          buat chapter pendek; yang penting isinya utuh.
        - target <= 1      -> merge dimatikan, tiap gambar jadi grup sendiri.
        """
        total = len(images)
        if total == 0:
            return []
        if target <= 1:
            return [[im] for im in images]
        
        target = min(target, total)
        base, extra = divmod(total, target)
        
        groups, idx = [], 0
        for i in range(target):
            size = base + (1 if i < extra else 0)
            groups.append(images[idx:idx + size])
            idx += size
        return groups
    
    def _prepared_height(self, image_data: bytes) -> int:
        """Tinggi gambar SETELAH _prepare_image (w500), dihitung dari header saja.
        
        Dipakai buat tahu tinggi strip sebelum merge. Kalau data nggak kebaca, balikin 0
        supaya gambar tetap ikut ke grup (tidak ada yang dibuang).
        """
        try:
            with Image.open(io.BytesIO(image_data)) as im:
                w, h = im.size
        except Exception:
            return 0
        if w > self.DEFAULT_WIDTH:
            return max(1, int(h * (self.DEFAULT_WIDTH / w)))
        return h
    
    def split_into_merge_groups_by_height(self, images_data: List[bytes],
                                          target: int = 10,
                                          max_height: Optional[int] = None) -> List[List[bytes]]:
        """
        Bagi gambar (urut baca) jadi grup merge dengan batas JUMLAH **dan TINGGI**.
        
        Kenapa perlu: SVT-AV1 menolak sumber yang lebih tinggi dari AVIF_MAX_HEIGHT
        (8704 px). Strip hasil merge bisa lewat batas itu, jadi grupnya dibatasi tinggi
        supaya strip tetap bisa di-encode SVT -- bukan dengan memotong gambar.
        
        Cara kerja (kalau `max_height` kosong -> persis `split_into_merge_groups`):
        1. Coba bagi RATA jadi min(total, target) grup (aturan lama: 1 chapter jadi
           maksimal `target` file, selisih jumlah gambar antar grup maksimal 1).
        2. Kalau SEMUA grup sudah muat (<= max_height), pakai hasil itu -- hasilnya sama
           seperti sebelum fitur batas tinggi ada.
        3. Kalau ada yang kelewat tinggi, packing ulang SELURUH daftar secara greedy
           berurutan: gambar dimasukkan selama masih muat, kalau penuh grup baru dibuka.
           Ini PEMECAHAN GRUP, bukan pemotongan gambar: pixel tetap utuh, cuma jumlah
           file outputnya bertambah (dan dibuat sesedikit mungkin).
        - gambar yang SENDIRIAN sudah lebih tinggi dari max_height tetap jadi grup
          sendiri secara utuh (nanti otomatis di-encode libaom oleh _encode_avif),
          bukan dipotong atau di-resize.
        - urutan gambar dijaga persis seperti input.
        """
        even = self.split_into_merge_groups(images_data, target)
        if not max_height or not images_data:
            return even
        if all(self._group_height(g) <= max_height for g in even):
            return even
        return self._split_group_by_height(images_data, max_height)
    
    def _group_height(self, group: List[bytes]) -> int:
        """Total tinggi strip kalau grup ini di-merge (dihitung setelah resize w500)."""
        return sum(self._prepared_height(data) for data in group)
    
    def _split_group_by_height(self, group: List[bytes],
                               max_height: Optional[int]) -> List[List[bytes]]:
        """
        Bagi satu daftar gambar (urut baca) jadi grup-grup berurutan yang total
        tingginya <= max_height.
        
        Greedy: gambar dimasukkan selama masih muat; kalau penuh, grup baru dibuka.
        Tinggi dihitung dari tinggi gambar SETELAH _prepare_image (w500) supaya pas
        dengan strip yang benar-benar di-encode. Nggak ada gambar yang dipotong.
        """
        if not max_height:
            return [group] if group else []
        
        subs: List[List[bytes]] = []
        current: List[bytes] = []
        current_h = 0
        for data in group:
            h = self._prepared_height(data)
            if current and current_h + h > max_height:
                subs.append(current)
                current, current_h = [], 0
            current.append(data)
            current_h += h
        if current:
            subs.append(current)
        return subs
    
    def _pack_to_cbz(self, images: List[Tuple[str, bytes]], cbz_path: Path) -> bool:
        try:
            with zipfile.ZipFile(cbz_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for filename, image_data in images:
                    zf.writestr(filename, image_data)
            
            # Validate CBZ
            return self._validate_cbz(cbz_path)
        except Exception:
            return False
    
    def _validate_cbz(self, cbz_path: Path) -> bool:
        """Validate CBZ file"""
        try:
            with zipfile.ZipFile(cbz_path, 'r') as zf:
                if len(zf.namelist()) == 0:
                    return False
                for name in zf.namelist():
                    data = zf.read(name)
                    if len(data) < 100:
                        return False
                return True
        except Exception:
            return False
    
    @abstractmethod
    def search(self, query: str) -> List[Dict[str, Any]]:
        pass
    
    @abstractmethod
    def get_manga_detail(self, url: str) -> Optional[Dict[str, Any]]:
        pass
    
    @abstractmethod
    def get_chapter_images_ordered(self, url: str) -> List[Dict[str, Any]]:
        pass
    
    def _process_chapter(self, chapter: Dict[str, Any], manga_folder: Path, 
                         progress: ProgressTracker, worker_id: int = 0) -> bool:
        """Process single chapter with validation"""
        chapter_title = chapter['title']
        chapter_num = re.search(r'[\d.]+', chapter_title)
        chapter_num = chapter_num.group() if chapter_num else '0'
        chapter_url = chapter['url']
        
        # Check if CBZ exists and is valid
        cbz_path = manga_folder / f"chapter-{chapter_num.zfill(3)}.cbz"
        if cbz_path.exists() and self._validate_cbz(cbz_path):
            progress.skip_chapter(chapter_title)
            return True
        
        # Remove invalid CBZ
        if cbz_path.exists():
            cbz_path.unlink(missing_ok=True)
        
        progress.start_chapter(chapter_title, worker_id)
        
        # Get images
        progress.update_chapter(chapter_title, "Fetching image list...")
        ordered_images = self.get_chapter_images_ordered(chapter_url)
        if not ordered_images:
            progress.fail_chapter(chapter_title, "No images found")
            return False
        
        progress.update_chapter(chapter_title, f"Found {len(ordered_images)} images")
        
        # 1) DOWNLOAD SEMUA gambar dulu (paralel, network-bound) -> simpan per order.
        #    Convert nanti setelah merge, biar 1 strip = 1x encode AVIF.
        downloaded = {}
        failed_images = 0
        results_lock = Lock()
        total = len(ordered_images)
        
        def _work(img):
            nonlocal failed_images
            try:
                img_data = self._download_image_with_retry(img['url'])
                if not img_data:
                    with results_lock:
                        failed_images += 1
                    return
                with results_lock:
                    downloaded[img['order']] = img_data
            except Exception:
                with results_lock:
                    failed_images += 1
        
        with ThreadPoolExecutor(max_workers=self.INNER_DOWNLOAD_WORKERS) as executor:
            futures = [executor.submit(_work, img) for img in ordered_images]
            for i, future in enumerate(as_completed(futures), 1):
                future.result()
                progress.update_chapter(chapter_title, f"Downloaded {i}/{total}...")
        
        # Urutkan sesuai order asli (posisi gambar di HTML) -> urutan baca dijamin sama
        ordered_data = [downloaded[k] for k in sorted(downloaded)]
        
        # Validate: must have at least 80% of images
        required = int(len(ordered_images) * 0.8)
        if len(ordered_data) < required:
            progress.fail_chapter(chapter_title, f"Too many failed images ({failed_images}/{len(ordered_images)})")
            return False
        
        # 2) MERGE: bagi jadi grup berurutan, tiap grup ditumpuk vertikal jadi 1 strip.
        #    Grup dibatasi jumlah gambar (MERGE_TARGET_COUNT) DAN total tinggi
        #    (AVIF_MAX_HEIGHT - margin) supaya strip tetap muat di-encode SVT-AV1.
        #    Nggak ada pixel yang dipotong: gambar cuma ditumpuk, bukan di-crop/resize.
        groups = self.split_into_merge_groups_by_height(
            ordered_data, self.MERGE_TARGET_COUNT,
            self.AVIF_MAX_HEIGHT - self.MERGE_HEIGHT_MARGIN)
        progress.update_chapter(chapter_title, f"Merging {len(ordered_data)} -> {len(groups)} images...")
        
        merged = {}
        
        def _merge(idx, group):
            try:
                with self._convert_sem:
                    avif_data = self._merge_group_to_avif(group)
                if avif_data:
                    with results_lock:
                        merged[idx] = [(f"{idx:03d}.avif", avif_data)]
                    return
            except Exception:
                pass
            # Fallback: strip gagal di-encode (mis. kepanjangan buat libavif) ->
            # jangan buang halaman, simpan per gambar. Urutan tetap (idx-01, idx-02, ...).
            fallback = []
            for j, img_data in enumerate(group, 1):
                with self._convert_sem:
                    avif_data = self._convert_to_avif(img_data)
                if avif_data:
                    fallback.append((f"{idx:03d}-{j:02d}.avif", avif_data))
            if fallback:
                with results_lock:
                    merged[idx] = fallback
        
        # Merge + encode = CPU-bound -> batasi sesuai core, jangan spawn semua grup
        with ThreadPoolExecutor(max_workers=self.CONVERT_CONCURRENCY) as executor:
            futures = [executor.submit(_merge, idx, group) for idx, group in enumerate(groups, 1)]
            for i, future in enumerate(as_completed(futures), 1):
                future.result()
                progress.update_chapter(chapter_title, f"Merged {i}/{len(groups)}...")
        
        # Hasil diurutkan per grup -> nama 001..010, urutan baca tetap
        cbz_images = []
        for idx in sorted(merged):
            cbz_images.extend(merged[idx])
        if not cbz_images:
            progress.fail_chapter(chapter_title, "Merge failed")
            return False
        
        # Pack to CBZ
        progress.update_chapter(chapter_title, "Packing CBZ...")
        if self._pack_to_cbz(cbz_images, cbz_path):
            size_kb = cbz_path.stat().st_size / 1024
            progress.complete_chapter(chapter_title, size_kb, len(cbz_images))
            return True
        else:
            progress.fail_chapter(chapter_title, "CBZ creation failed")
            return False
    
    def download_manga(self, manga_url: str, max_workers: int = None, 
                       progress: ProgressTracker = None,
                       chapters: Optional[List[Dict[str, Any]]] = None) -> bool:
        """
        Download manga with progress UI.
        `chapters` opsional: kalau dikasih (dari pilihan user), cuma itu yang di-download.
        Kalau kosong, semua chapter di-download.
        """
        max_workers = max_workers or self.MAX_WORKERS
        
        print()
        print("╔══════════════════════════════════════════════════════════╗")
        print("║           📥 MANGA BATCH DOWNLOADER                     ║")
        print(f"║     {max_workers} Workers | AVIF {self.AVIF_CODEC} s{self.AVIF_SPEED} tune{self.AVIF_TUNE} crf{self.AVIF_CRF} | merge {self.MERGE_TARGET_COUNT} → CBZ ║")
        print("╚══════════════════════════════════════════════════════════╝")
        print()
        
        # Get manga detail
        print("[1/4] Fetching manga details...")
        detail = self.get_manga_detail(manga_url)
        if not detail:
            print("  [ERROR] Failed to get manga details")
            return False
        
        title = detail['title']
        if chapters:
            # User pilih chapter tertentu -> pakai itu (di-reverse biar mulai dari chapter lama)
            chapters = list(reversed(chapters))
        else:
            chapters = list(reversed(detail['chapters']))
        info = detail['info']
        cover_url = detail.get('cover_url', '')
        
        print(f"  Title: {title}")
        print(f"  Chapters: {len(chapters)}")
        print(f"  Workers: {max_workers}")
        print()
        
        # Create folder
        manga_folder = self.download_dir / self._sanitize_filename(title)
        manga_folder.mkdir(parents=True, exist_ok=True)
        
        # Save cover (ORIGINAL format, no conversion) — SELALU ambil kandidat
        # dengan RESOLUSI PALING BESAR (=gambar ori), bukan asal pertama yang
        # kebetulan mirip thumbnail. Kandidat di-download & dibandingkan semua,
        # yang terbesar pixel-nya yang disimpan.
        print("[2/4] Saving cover...")
        cover_candidates = self._dedupe_urls(list(detail.get('cover_candidates') or []) + [cover_url])
        cover_candidates = [u for u in cover_candidates if not self._is_placeholder_url(u)]
        
        if not cover_candidates:
            print("  (no cover URL)")
        else:
            best = None  # (pixels, ext, bytes, "WxH")
            skip_hosts = set()   # host yang gagal konek -> jangan dicoba lagi
            done_paths = set()   # (group, path) yang sudah dievaluasi -> hindari coba mirror dobel
            
            for i, cand in enumerate(cover_candidates, 1):
                try:
                    split = urlsplit(cand)
                    host = split.netloc.lower()
                    # group = host tanpa TLD: normalize foo.komiku.to & foo.komiku.org
                    # jadi mirror yang sama (biar file dobel nggak di-download 2x / nggak
                    # nunggu timeout buat mirror mati).
                    group = host.rsplit('.', 1)[0] if host.count('.') >= 2 else host
                    if group in skip_hosts:
                        continue
                    path_key = (group, split.path)
                    if path_key in done_paths:
                        continue
                except Exception:
                    continue
                
                try:
                    resp = self.session.get(cand, timeout=30)
                    if resp.status_code != 200 or len(resp.content) <= 100:
                        continue
                    # Pastiin beneran gambar & bukan 1x1 / placeholder
                    probe = Image.open(io.BytesIO(resp.content))
                    if probe.width < 100 or probe.height < 100:
                        print(f"  (kandidat {i} kekecilan {probe.width}x{probe.height}, coba berikutnya)")
                        continue
                    done_paths.add(path_key)
                    ext = self._detect_image_ext(resp.content, resp.headers.get('Content-Type', ''))
                    pixels = probe.width * probe.height
                    if best is None or pixels > best[0]:
                        best = (pixels, ext, resp.content, f"{probe.width}x{probe.height}")
                        print(f"  ✓ kandidat {i} = {probe.width}x{probe.height} ({len(resp.content)} bytes)")
                except (requests.exceptions.ConnectTimeout,
                        requests.exceptions.ReadTimeout,
                        requests.exceptions.ConnectionError,
                        requests.exceptions.Timeout):
                    # Host mati / koneksi gagal -> skip semua kandidat di host itu,
                    # jangan sampai nunggu timeout 30s berulang-ulang.
                    skip_hosts.add(group)
                    print(f"  ✗ kandidat {i} host {host} gagal konek, skip host ini")
                except Exception as e:
                    print(f"  ✗ kandidat {i} gagal: {e}")
            
            if best:
                # Bersihin cover lama (kalau formatnya beda, jangan nyisa 2 file)
                for old in manga_folder.glob("cover.*"):
                    old.unlink(missing_ok=True)
                cover_path = manga_folder / f"cover{best[1]}"
                with open(cover_path, 'wb') as f:
                    f.write(best[2])
                print(f"  ✓ Cover saved as cover{best[1]} ({best[3]}, {len(best[2])} bytes)")
                saved = True
            else:
                print("  (failed to download cover)")
        
        # Save info.json (LENGKAP & konsisten untuk komiku + komikindo)
        print("[3/4] Saving info.json...")
        info_path = manga_folder / "info.json"
        merged_info = {
            'title': info.get('title') or detail.get('title') or title,
            'genres': info.get('genres', detail.get('genres', [])),
            'synopsis': info.get('synopsis', detail.get('synopsis', '')),
            'author': info.get('author', ''),
            'type': info.get('type', ''),
            'status': info.get('status', ''),
            'total_chapters': info.get('total_chapters', detail.get('total_chapters', len(chapters))),
        }
        # Field opsional biar tetap kaya (kalau ada di scraper-nya)
        for key in ('alternative_title', 'artist'):
            val = info.get(key) or detail.get(key)
            if val:
                merged_info[key] = val
        self._save_info_json(merged_info, info_path)
        print("  ✓ Info saved")
        
        # Download chapters
        print(f"[4/4] Downloading {len(chapters)} chapters...")
        print()
        
        if not progress:
            progress = ProgressTracker(len(chapters))
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {}
            for i, chapter in enumerate(chapters):
                future = executor.submit(
                    self._process_chapter, chapter, manga_folder, progress, i % max_workers
                )
                futures[future] = chapter
            
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    pass
        
        progress.summary()
        
        # List CBZ files
        cbz_files = list(manga_folder.glob("*.cbz"))
        print(f"\n  📁 Location: {manga_folder}")
        print(f"  📚 CBZ files: {len(cbz_files)}")
        
        return True
