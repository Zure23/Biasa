#!/usr/bin/env python3
"""
CLI Interface for Comic Scraper
Interactive menu with search, selection, and progress display
"""
import os
import sys
import re
import time
from pathlib import Path
from typing import List, Dict, Any, Optional

# Rich for beautiful CLI
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.prompt import Prompt, IntPrompt, Confirm
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
    from rich.live import Live
    from rich.text import Text
    from rich.columns import Columns
    from rich import box
    HAS_RICH = True
except ImportError:
    HAS_RICH = False
    print("[WARN] rich not installed. Install with: pip install rich")


class ComicCLI:
    """Interactive CLI for comic scraper"""
    
    def __init__(self):
        if HAS_RICH:
            self.console = Console()
        self.scraper = None
        self.source_name = ""
    
    def print(self, *args, **kwargs):
        if HAS_RICH:
            self.console.print(*args, **kwargs)
        else:
            print(*args)
    
    def show_banner(self):
        banner = """
╔══════════════════════════════════════════════════════════╗
║           📚 KOMIK SCRAPER v2.0                         ║
║     Download manga from Indonesian sites                ║
║     komiku.org, komikindo.ch & softkomik.co             ║
╚══════════════════════════════════════════════════════════╝
        """
        if HAS_RICH:
            self.console.print(Panel(banner.strip(), style="bold cyan", box=box.DOUBLE))
        else:
            print(banner)
    
    def select_source(self) -> tuple:
        """Let user select the manga source"""
        self.print("\nPilih sumber manga:")
        self.print("  [1] komiku.org (tanpa Cloudflare, lebih cepat)")
        self.print("  [2] komikindo.ch (Cloudflare protected)")
        self.print("  [3] softkomik.co (butuh token sesi per chapter)")
        self.print("  [b] Kembali / ganti pilihan")
        
        try:
            choice = input("Pilih [1/2/3/b]: ").strip() or "1"
        except EOFError:
            choice = "1"
        
        if choice.lower() == 'b' or choice == '0':
            return None, None  # Back to main menu
        
        if choice == '1':
            from .komiku import KomikuScraper
            self.source_name = "komiku.org"
            return 'komiku', KomikuScraper()
        elif choice == '3':
            from .softkomik import SoftkomikScraper
            self.source_name = "softkomik.co"
            return 'softkomik', SoftkomikScraper()
        else:
            from .komikindo import KomikindoScraper
            self.source_name = "komikindo.ch"
            return 'komikindo', KomikindoScraper()
    
    def search_manga(self, scraper) -> Optional[Dict[str, Any]]:
        """Search for manga and let user select"""
        try:
            query = input("\nMasukkan judul manga: ")
        except EOFError:
            return None
        
        if not query.strip():
            self.print("[ERROR] Judul tidak boleh kosong!")
            return None
        
        query = query.strip()
        self.print(f"\nMencari '{query}'...")
        
        results = scraper.search(query)
        
        if not results:
            self.print("❌ Tidak ditemukan hasil!")
            return None
        
        # Show results
        if HAS_RICH:
            table = Table(title="Hasil Pencarian", box=box.ROUNDED)
            table.add_column("No", style="dim", width=4)
            table.add_column("Judul", style="cyan")
            table.add_column("Info", style="green")
            
            for i, result in enumerate(results[:10], 1):
                info_parts = []
                if result.get('type'):
                    info_parts.append(result['type'])
                if result.get('chapter_latest'):
                    info_parts.append(f"Ch: {result['chapter_latest']}")
                if result.get('rating'):
                    info_parts.append(f"⭐{result['rating']}")
                info = " | ".join(info_parts) if info_parts else ""
                table.add_row(str(i), result['title'], info)
            
            self.console.print(table)
        else:
            for i, result in enumerate(results[:10], 1):
                print(f"  [{i}] {result['title']}")
        
        # Select
        if len(results) == 1:
            self.print(f"\n✅ Auto-selected: {results[0]['title']}")
            return results[0]
        
        try:
            choice = int(input("Pilih manga (nomor): ") or "1")
        except (EOFError, ValueError):
            choice = 1
        
        if choice < 1 or choice > len(results):
            self.print("❌ Pilihan tidak valid!")
            return None
        
        return results[choice - 1]
    
    def show_manga_detail(self, detail: Dict[str, Any]):
        """Show manga details"""
        if not detail:
            return
        
        if HAS_RICH:
            # Build info text
            info_text = Text()
            info_text.append(f"📚 {detail['title']}\n", style="bold cyan")
            
            if detail.get('info'):
                info = detail['info']
                if info.get('type'):
                    info_text.append(f"Type: {info['type']}\n", style="green")
                if info.get('author'):
                    info_text.append(f"Author: {info['author']}\n", style="green")
                if info.get('status'):
                    info_text.append(f"Status: {info['status']}\n", style="green")
            
            if detail.get('genres'):
                info_text.append(f"Genres: {', '.join(detail['genres'])}\n", style="yellow")
            
            if detail.get('chapters'):
                info_text.append(f"\nTotal Chapter: {len(detail['chapters'])}", style="bold green")
            
            self.console.print(Panel(info_text, title="Manga Info", box=box.ROUNDED))
        else:
            print(f"\n📚 {detail['title']}")
            if detail.get('info'):
                for k, v in detail['info'].items():
                    print(f"  {k}: {v}")
    
    def select_chapters(self, chapters: List[Dict]) -> List[Dict]:
        """Let user select which chapters to download"""
        total = len(chapters)
        
        self.print(f"\nTotal Chapter: {total}")
        self.print("Pilih chapter:")
        self.print("  [1] Semua chapter")
        self.print("  [2] Custom range (contoh: 1-10 atau 1,5,10-15)")
        self.print("  [3] Chapter terakhir saja")
        
        try:
            choice = int(input("Pilih [1/2/3]: ") or "1")
        except (EOFError, ValueError):
            choice = 1
        
        if choice == 1:
            return chapters
        
        if choice == 3:
            try:
                n = int(input("Berapa chapter terakhir? ") or "10")
            except (EOFError, ValueError):
                n = 10
            return chapters[-n:]
        
        # Custom range
        try:
            range_str = input("Masukkan range (contoh: 1-10): ") or "1-10"
        except EOFError:
            range_str = "1-10"
        
        selected = self._parse_chapter_range(range_str, chapters)
        return selected
    
    def _parse_chapter_range(self, range_str: str, chapters: List[Dict]) -> List[Dict]:
        """Parse chapter range string like '1-10' or '1,5,10-15'"""
        selected = []
        selected_urls = set()
        
        for part in range_str.split(','):
            part = part.strip()
            if not part:
                continue
            
            if '-' in part:
                try:
                    start_str, end_str = part.split('-', 1)
                    start_str = start_str.strip()
                    end_str = end_str.strip()
                    
                    # Handle open-ended ranges like "50-"
                    if not end_str:
                        end_num = 999999
                    else:
                        end_num = float(end_str)
                    
                    if not start_str:
                        start_num = 0
                    else:
                        start_num = float(start_str)
                    
                    for ch in chapters:
                        ch_num = self._extract_chapter_number(ch['title'])
                        if ch_num is not None and start_num <= ch_num <= end_num:
                            if ch['url'] not in selected_urls:
                                selected.append(ch)
                                selected_urls.add(ch['url'])
                except ValueError:
                    pass
            else:
                # Single chapter
                try:
                    target_num = float(part)
                    for ch in chapters:
                        ch_num = self._extract_chapter_number(ch['title'])
                        if ch_num is not None and abs(ch_num - target_num) < 0.01:
                            if ch['url'] not in selected_urls:
                                selected.append(ch)
                                selected_urls.add(ch['url'])
                except ValueError:
                    pass
        
        return selected
    
    def _extract_chapter_number(self, title: str) -> Optional[float]:
        """Extract chapter number from title"""
        # Match patterns like "Chapter 1", "Ch. 1", "Chapter 1.5", etc
        match = re.search(r'(?:chapter|ch\.?)\s*([\d.]+)', title, re.IGNORECASE)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                pass
        
        # Try to find any number
        match = re.search(r'([\d.]+)', title)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                pass
        
        return None
    
    def download_with_progress(self, scraper, manga_url: str, chapters: List[Dict],
                               max_workers: int = None):
        """Download chapters with live progress display"""
        from .base import ProgressTracker

        total = len(chapters)
        if total == 0:
            self.print("[WARN] Tidak ada chapter untuk didownload!")
            return
        
        # Pakai default per situs (komiku 10, komikindo 5)
        max_workers = max_workers or getattr(scraper, 'MAX_WORKERS', 10)
        
        self.print(f"\n📥 Download {total} chapters dengan {max_workers} workers...")
        self.print(f"   Format: AVIF {getattr(scraper, 'AVIF_CODEC', 'svt')} "
                   f"s{getattr(scraper, 'AVIF_SPEED', 5)} "
                   f"tune{getattr(scraper, 'AVIF_TUNE', 1)} "
                   f"crf{getattr(scraper, 'AVIF_CRF', 43)} w500 "
                   f"(merge {getattr(scraper, 'MERGE_TARGET_COUNT', 10)} gambar/chapter) → CBZ\n")
        
        # Create progress tracker
        progress = ProgressTracker(total)
        
        # Start download (kirim chapter pilihan user, bukan fetch ulang semua)
        scraper.download_manga(manga_url, max_workers=max_workers, progress=progress,
                               chapters=chapters)
        
        progress.summary()
    
    def run(self):
        """Main CLI loop - continuos mode with back option"""
        self.show_banner()
        
        loop_count = 0
        max_loops = 3  # Prevent infinite loop on EOF
        
        while True:
            # Safety: if EOF exhausted, exit after max_loops
            if loop_count >= max_loops:
                self.print("\n[INFO] Input exhausted. Exiting...")
                break
            loop_count += 1
            # Select source (bisa ganti kapan saja)
            source_name, scraper = self.select_source()
            
            # Handle back from source selection
            if source_name is None or scraper is None:
                continue
            
            self.scraper = scraper
            
            # Search manga
            selected = self.search_manga(scraper)
            if not selected:
                # Ask if want to try another title
                try:
                    confirm = input("\nCoba judul lain di situs yang sama? [y/n]: ").strip().lower()
                except EOFError:
                    confirm = 'n'
                if confirm != 'y':
                    # Back to source selection
                    continue
                # Try again
                continue
            
            # Get detail
            self.print(f"\n📖 Mendapatkan detail: {selected['title']}...")
            detail = scraper.get_manga_detail(selected['url'])
            
            if not detail:
                self.print("❌ Gagal mendapatkan detail manga!")
                continue
            
            self.show_manga_detail(detail)
            
            # Select chapters
            chapters = self.select_chapters(detail['chapters'])
            
            if not chapters:
                self.print("[WARN] Tidak ada chapter dipilih!")
                continue
            
            # Confirm download
            self.print(f"\nAkan didownload {len(chapters)} chapter")
            try:
                confirm = input("Lanjutkan download? [y/n]: ").strip().lower()
            except EOFError:
                confirm = 'y'
            if confirm != 'y':
                continue
            
            # Download
            manga_url = selected['url']
            self.download_with_progress(scraper, manga_url, chapters)
            
            # After download complete
            self.print("\n" + "="*50)
            if HAS_RICH:
                self.print("[bold green]🎉 Download selesai![/bold green]")
            else:
                print("\n🎉 Download selesai!")
            
            # Ask what to do next
            try:
                action = input("\nApa next? (1: Download lagi, 2: Ganti situs, 3: Exit): ").strip()
            except EOFError:
                action = '3'
            
            if action == "3" or action.lower() == "exit":
                self.print("\n👋 Sampai jumpa!")
                break
            elif action == "2":
                self.print("\n➡️  Ganti ke situs lain...")
                continue
            else:
                # Download lagi di situs yang sama
                self.print("\n📚 Coba manga lain di situs yang sama...")
                continue


def main():
    """Entry point"""
    cli = ComicCLI()
    cli.run()


if __name__ == '__main__':
    main()
