#!/usr/bin/env python3
"""
Download images from komikindo.ch and convert to WebP and AVIF
"""
import os
import io
import pillow_avif
from PIL import Image
from scraper import KomikindoScraper

# Settings
OUTPUT_DIR = "converted_images"
TARGET_WIDTH = 500
QUALITY = 40

def download_and_convert():
    """Download images and convert to WebP and AVIF"""
    
    # Create output directories
    os.makedirs(f"{OUTPUT_DIR}/original", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/webp", exist_ok=True)
    os.makedirs(f"{OUTPUT_DIR}/avif", exist_ok=True)
    
    scraper = KomikindoScraper()
    
    print("=== DOWNLOAD & CONVERT IMAGES ===")
    print()
    
    # Get ordered images
    print("Getting images from komikindo.ch...")
    ordered = scraper.get_chapter_images_ordered('https://komikindo.ch/magic-emperor-chapter-906/')
    print(f"Found {len(ordered)} images")
    print()
    
    total_original = 0
    total_webp = 0
    total_avif = 0
    
    for img in ordered:
        order = img['order']
        url = img['url']
        
        print(f"Processing image {order}/{len(ordered)}...")
        
        # Download image
        resp = scraper.session.get(url, timeout=30)
        original_data = resp.content
        original_size = len(original_data)
        total_original += original_size
        
        # Save original
        original_path = f"{OUTPUT_DIR}/original/{order:03d}.jpeg"
        with open(original_path, 'wb') as f:
            f.write(original_data)
        
        # Open image
        image = Image.open(io.BytesIO(original_data))
        orig_width, orig_height = image.size
        
        # Resize to target width (maintain aspect ratio)
        if orig_width > TARGET_WIDTH:
            ratio = TARGET_WIDTH / orig_width
            new_height = int(orig_height * ratio)
            image = image.resize((TARGET_WIDTH, new_height), Image.LANCZOS)
        
        # Convert to WebP
        webp_path = f"{OUTPUT_DIR}/webp/{order:03d}.webp"
        image.save(webp_path, "WEBP", quality=QUALITY)
        webp_size = os.path.getsize(webp_path)
        total_webp += webp_size
        
        # Convert to AVIF
        avif_path = f"{OUTPUT_DIR}/avif/{order:03d}.avif"
        image.save(avif_path, "AVIF", quality=QUALITY)
        avif_size = os.path.getsize(avif_path)
        total_avif += avif_size
        
        print(f"  Original: {orig_width}x{orig_height} | {original_size/1024:.1f} KB")
        print(f"  WebP:     {TARGET_WIDTH}x{int(orig_height * (TARGET_WIDTH/orig_width)) if orig_width > TARGET_WIDTH else orig_height} | {webp_size/1024:.1f} KB ({(1-webp_size/original_size)*100:.1f}% smaller)")
        print(f"  AVIF:     {TARGET_WIDTH}x{int(orig_height * (TARGET_WIDTH/orig_width)) if orig_width > TARGET_WIDTH else orig_height} | {avif_size/1024:.1f} KB ({(1-avif_size/original_size)*100:.1f}% smaller)")
        print()
    
    print("=== SUMMARY ===")
    print(f"Original: {total_original/1024/1024:.2f} MB")
    print(f"WebP:     {total_webp/1024/1024:.2f} MB ({(1-total_webp/total_original)*100:.1f}% smaller)")
    print(f"AVIF:     {total_avif/1024/1024:.2f} MB ({(1-total_avif/total_original)*100:.1f}% smaller)")
    print()
    print(f"Files saved to: {OUTPUT_DIR}/")

if __name__ == "__main__":
    download_and_convert()
