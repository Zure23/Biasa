#!/usr/bin/env python3
"""Bikin set sample AVIF untuk 1 halaman tertentu (judul/chapter/halaman bebas).

Isi set:
  - ref_svt_crf44_ffmpeg.avif      : ffmpeg+libsvtav1 crf 44 preset 5 (referensi)
  - svt_pillow_s5_tune{1..4}.avif  : pillow-avif-plugin/SVT v4.1.0, speed 5
  - svt_pillow_s6_tune4.avif       : idem tapi speed 6
  - scraper_aom_s6_q40.avif        : jalur scraper libaom speed 6 quality 40
Semua sample pillow dikalibrasi CRF-nya supaya UKURANNYA mendekati file referensi.

Pakai:
  python3 bench_page_samples.py --manga-url <url> --chapter 1 --page 10
"""
import argparse
import io
import os
import re
import statistics
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PIL import Image, ImageFilter
import pillow_avif  # noqa: F401

from scraper import KomikuScraper

HERE = Path(__file__).resolve().parent
WORK = HERE / "bench_page_compare"
SAMPLES = HERE / "samples"
LAP = ImageFilter.Kernel((3, 3), [-1, -1, -1, -1, 8, -1, -1, -1, -1], scale=1, offset=0)


def sh(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def even_pad(im):
    w, h = im.size
    ew, eh = w + (w & 1), h + (h & 1)
    if (ew, eh) == (w, h):
        return im
    c = Image.new("RGB", (ew, eh), (255, 255, 255))
    c.paste(im, (0, 0))
    return c


def ssim(avif_path, ref_png):
    png = WORK / f"_dec_{Path(avif_path).stem}.png"
    sh(["avifdec", str(avif_path), str(png), "-q", "100"])
    r = sh(["ffmpeg", "-hide_banner", "-i", str(png), "-i", str(ref_png),
            "-lavfi", "ssim", "-f", "null", "-"])
    m = re.search(r"All:([0-9.]+)", r.stderr or "")
    return float(m.group(1)) if m else float("nan")


def detail(avif_path):
    png = WORK / f"_dec_{Path(avif_path).stem}.png"
    i = Image.open(png).convert("L")
    return statistics.pvariance(list(i.filter(LAP).get_flattened_data()))


def pick_chapter(sc, manga_url, chapter_no):
    detail_doc = sc.get_manga_detail(manga_url)
    if not detail_doc:
        raise SystemExit("gagal ambil detail manga")
    for ch in detail_doc["chapters"]:
        m = re.search(r"(\d+(?:\.\d+)?)", ch["title"])
        if m and abs(float(m.group(1)) - chapter_no) < 1e-6:
            return detail_doc, ch
    raise SystemExit(f"chapter {chapter_no} tidak ketemu")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manga-url", required=True)
    ap.add_argument("--chapter", type=int, default=1)
    ap.add_argument("--page", type=int, default=10)
    ap.add_argument("--merge", type=int, default=1,
                    help="gabung N halaman berurutan jadi 1 strip (seperti merge scraper)")
    args = ap.parse_args()

    WORK.mkdir(parents=True, exist_ok=True)
    SAMPLES.mkdir(parents=True, exist_ok=True)
    sc = KomikuScraper(str(WORK))
    sc.AVIF_SPEED = 6          # setelan scraper sekarang
    sc.DEFAULT_QUALITY = 40

    print(f"🔎 ambil {args.manga_url} chapter {args.chapter} halaman {args.page} ...")
    detail_doc, ch = pick_chapter(sc, args.manga_url, args.chapter)
    imgs = sc.get_chapter_images_ordered(ch["url"])
    item = imgs[args.page - 1]
    print(f"   {detail_doc['title']} / {ch['title']} / hal {args.page}: {item['url'].split('/')[-1]}")

    pages = imgs[args.page - 1: args.page - 1 + args.merge]
    prepared = []
    for it in pages:
        d = sc._download_image_with_retry(it["url"])
        if not d:
            raise SystemExit(f"download gagal: {it['url']}")
        prepared.append(sc._prepare_image(Image.open(io.BytesIO(d))))   # w500, method scraper asli

    if len(prepared) == 1:
        base = prepared[0]
    else:
        # samakan dengan cara merge scraper: kanvas putih, gambar di-center, tanpa celah
        width = max(p.width for p in prepared)
        height = sum(p.height for p in prepared)
        base = Image.new("RGB", (width, height), (255, 255, 255))
        y = 0
        for p in prepared:
            base.paste(p, ((width - p.width) // 2, y))
            y += p.height
        print(f"   merge {len(prepared)} halaman -> {base.size}  "
              f"(tinggi: {', '.join(str(p.height) for p in prepared)})")
    png = WORK / "page_w500.png"
    base.save(png)
    png_even = WORK / "page_w500_even.png"
    even_pad(base).save(png_even)
    print(f"   ukuran w500: {base.size}  (input ffmpeg: {Image.open(png_even).size})")

    im = base.convert("RGB")

    # --- referensi: ffmpeg + libsvtav1 crf 44 ---
    ref = SAMPLES / "ref_svt_crf44_ffmpeg.avif"
    t = time.perf_counter()
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(png_even),
                    "-vf", "scale=in_range=full:out_range=full", "-frames:v", "1",
                    "-c:v", "libsvtav1", "-crf", "44", "-preset", "5",
                    "-pix_fmt", "yuv420p", "-color_range", "pc", str(ref)], check=True)
    ref_time = time.perf_counter() - t
    target = ref.stat().st_size
    v_ref = ssim(ref, png_even)
    print(f"\nreferensi ffmpeg crf44: {target:,} B  SSIM {v_ref:.4f}  {ref_time:.2f}s"
          f"  (target ukuran buat sample pillow)")

    # --- sample pillow: kalibrasi crf supaya ukuran ~ target ---
    def enc_pillow(o, speed, crf, tune):
        b = io.BytesIO()
        im.save(b, "AVIF", codec="svt", speed=speed, quality=40,
                advanced=[("tune", tune), ("crf", crf)])
        o.write_bytes(b.getvalue())
        return o.stat().st_size

    def calibrate(speed, tune, lo=16, hi=70):
        best = None
        while lo <= hi:
            mid = (lo + hi) // 2
            o = WORK / f"_cal_s{speed}_t{tune}_{mid}.avif"
            n = enc_pillow(o, speed, mid, tune)
            if best is None or abs(n - target) < abs(best[2] - target):
                best = (mid, o, n)
            if n > target:
                lo = mid + 1
            else:
                hi = mid - 1
        return best

    print(f"\n{'sample':32} {'crf':>4} {'bytes':>8} {'vs ref':>8} {'SSIM':>8} {'detail':>7} {'waktu':>7}")
    print(f"{'ref_svt_crf44_ffmpeg':32} {'-':>4} {target:>8,} {0.0:>7.1f}% {v_ref:>8.4f} {detail(ref):>7.0f} {ref_time:>6.2f}s")
    for name, speed, tune in [("svt_pillow_s5_tune1", 5, 1), ("svt_pillow_s5_tune2", 5, 2),
                              ("svt_pillow_s5_tune3", 5, 3), ("svt_pillow_s5_tune4", 5, 4),
                              ("svt_pillow_s6_tune4", 6, 4)]:
        t0 = time.perf_counter()
        crf, o, n = calibrate(speed, tune)
        dt = time.perf_counter() - t0
        out = SAMPLES / f"{name}.avif"
        out.write_bytes(o.read_bytes())
        print(f"{name:32} {crf:>4} {n:>8,} {(n-target)/target*100:>7.1f}% "
              f"{ssim(out, png):>8.4f} {detail(out):>7.0f} {dt/8:>6.2f}s")

    # --- pembanding jalur scraper (libaom speed 6 q40) ---
    sc.AVIF_SPEED, sc.DEFAULT_QUALITY = 6, 40
    aom = SAMPLES / "scraper_aom_s6_q40.avif"
    t = time.perf_counter()
    aom.write_bytes(sc._encode_avif(im))
    dt = time.perf_counter() - t
    n = aom.stat().st_size
    print(f"{'scraper_aom_s6_q40':32} {'-':>4} {n:>8,} {(n-target)/target*100:>7.1f}% "
          f"{ssim(aom, png):>8.4f} {detail(aom):>7.0f} {dt:>6.2f}s")
    print(f"\n📁 {SAMPLES}")


if __name__ == "__main__":
    main()
