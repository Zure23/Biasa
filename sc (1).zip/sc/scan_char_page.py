#!/usr/bin/env python3
"""
Scan halaman sebuah chapter dan cari halaman yang paling "banyak karakter".
Indikator: rasio piksel warna kulit (skin-tone) + kepadatan tepi (detail) + kecerahan.
Scraper asli (scraper/) tidak diubah, hanya di-import.

Pakai:
    python3 scan_char_page.py --query "Eleceed" --chapter 1 --min-page 6 --max-page 30
"""
import io
import os
import re
import sys
import argparse
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PIL import Image, ImageFilter
import pillow_avif  # noqa: F401

from scraper import KomikuScraper

OUT = Path(__file__).resolve().parent / "bench_page_compare"


def metrics(im):
    """Kembalikan (skin_ratio, edge_density, brightness)."""
    rgb = im.convert("RGB")
    small = rgb.resize((max(im.width // 2, 1), max(im.height // 2, 1)))
    pix = list(small.getdata())
    n = len(pix)
    skin = 0
    for r, g, b in pix:
        if r > 95 and g > 40 and b > 20 and r > g and r > b and (max(r, g, b) - min(r, g, b)) > 15 and abs(r - g) > 15:
            skin += 1
    gray = rgb.convert("L")
    e = gray.filter(ImageFilter.FIND_EDGES)
    ep = list(e.getdata())
    edge = sum(1 for p in ep if p > 30) / len(ep)
    px = list(gray.getdata())
    bright = sum(px) / len(px)
    return skin / n, edge, bright


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--query", required=True)
    ap.add_argument("--chapter", type=int, default=1)
    ap.add_argument("--min-page", type=int, default=6)
    ap.add_argument("--max-page", type=int, default=30)
    args = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    sc = KomikuScraper(str(OUT))

    print(f"🔎 search: {args.query}")
    results = sc.search(args.query)
    if not results:
        raise SystemExit("hasil search kosong")
    for i, r in enumerate(results[:5], 1):
        print(f"  {i}. {r.get('title')}  {r.get('url')}")
    picked = results[0]
    print(f"→ pakai: {picked['title']}\n")

    detail = sc.get_manga_detail(picked["url"])
    if not detail:
        raise SystemExit("detail gagal")
    ch = None
    for c in detail["chapters"]:
        m = re.search(r"(\d+(?:\.\d+)?)", c["title"])
        if m and abs(float(m.group(1)) - args.chapter) < 1e-6:
            ch = c
            break
    if not ch:
        raise SystemExit(f"chapter {args.chapter} tidak ada")
    print(f"📖 {detail['title']} -> {ch['title']}  {ch['url']}\n")

    imgs = sc.get_chapter_images_ordered(ch["url"])
    print(f"total gambar: {len(imgs)}\n")

    rows = []
    upper = min(args.max_page, len(imgs))
    for i in range(args.min_page - 1, upper):
        data = sc._download_image_with_retry(imgs[i]["url"])
        if not data:
            print(f"  p{i+1:>3}: download gagal")
            continue
        im = sc._prepare_image(Image.open(io.BytesIO(data)))
        skin, edge, bright = metrics(im)
        rows.append((skin, edge, bright, i + 1, im.size, imgs[i]["url"]))
        print(f"  p{i+1:>3}: skin={skin*100:5.1f}%  edge={edge*100:4.1f}%  bright={bright:5.1f}  {im.width}x{im.height}")

    print("\n== ranking (skin ratio, lalu edge) ==")
    for skin, edge, bright, page, size, url in sorted(rows, key=lambda r: (r[0], r[1]), reverse=True)[:5]:
        print(f"  p{page:>3}  skin={skin*100:5.1f}%  edge={edge*100:4.1f}%  bright={bright:5.1f}  {size[0]}x{size[1]}")


if __name__ == "__main__":
    main()
