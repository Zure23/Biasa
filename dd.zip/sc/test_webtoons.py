#!/usr/bin/env python3
"""
Test logika scraper Webtoons (Indonesia) -- TANPA jaringan.

Yang diuji adalah bagian yang gampang rusak dan tidak kelihatan di layar:
  - penomoran chapter dari judul episode situs (prolog, mini/bonus, ganti musim,
    dan judul yang sama sekali tidak memuat nomor) -- aturannya nyontek extension
    resminya (sample/Webtoons.kt), jadi di sini dipatok hasilnya
  - nomor yang ditulis di judul chapter = nomor yang dibaca base.py buat nama
    berkas CBZ (kalau meleset, chapter bisa ketimpa / salah urut)
  - deteksi judul canvas vs webtoon dari URL + ambil title_no
  - kualitas gambar penuh (buang ?type=q90, sisakan ?type=opti)
  - pembacaan kartu listing (halaman ranking ada genre, halaman pencarian tidak)

Jalankan: python test_webtoons.py   (atau pytest test_webtoons.py)
"""
import tempfile

from bs4 import BeautifulSoup

from scraper.webtoons import WebtoonsScraper


def _scraper(payload=None) -> WebtoonsScraper:
    """Scraper dengan API mobile dipalsukan (biar tesnya offline)."""
    sc = WebtoonsScraper(tempfile.mkdtemp(prefix="test_webtoons_"))
    sc._api_get = lambda path, params=None: payload
    return sc


def _episode(no, judul, link=None):
    return {
        'episodeNo': no,
        'episodeTitle': judul,
        'viewerLink': link or f"/id/uji/seri/ep-{no}/viewer?title_no=1&episode_no={no}",
        'exposureDateMillis': 1700000000000,
        'hasBgm': False,
    }


def _payload(*episodes):
    return {'result': {'episodeList': list(episodes), 'nextCursor': 0}}


# --------------------------------------------------------------------- satuan
def test_format_number():
    assert WebtoonsScraper._format_number(4.0) == '4'
    assert WebtoonsScraper._format_number(138) == '138'
    assert WebtoonsScraper._format_number(5.01) == '5.01'
    assert WebtoonsScraper._format_number(0.0) == '0'
    assert WebtoonsScraper._format_number(None) == '0'
    print("✓ _format_number: 4.0 -> '4', 5.01 -> '5.01'")


def test_tipe_dan_title_no_dari_url():
    sc = _scraper()
    webtoon = "https://www.webtoons.com/id/romantic-fantasy/serena/list?title_no=5001"
    canvas = "https://www.webtoons.com/id/canvas/meme-girls/list?title_no=304446"
    lama = "https://www.webtoons.com/challenge/episodeList?titleNo=304446"

    assert sc.chapter_type_from_url(webtoon) == 'webtoon'
    assert sc.chapter_type_from_url(canvas) == 'canvas'
    assert sc.chapter_type_from_url(lama) == 'canvas', "pola URL lama /challenge harus canvas"
    assert sc.title_no_from_url(webtoon) == '5001'
    assert sc.title_no_from_url(lama) == '304446', "parameter titleNo (tanpa _) juga harus kebaca"
    assert sc.title_no_from_url("https://www.webtoons.com/id/fantasy/x/list") == ''
    print("✓ jenis judul (webtoon/canvas) & title_no terbaca dari semua pola URL")


def test_kualitas_penuh():
    sc = _scraper()
    dasar = "https://webtoon-phinf.pstatic.net/20221212_204/123_JPEG/Serena_00_01_01.jpg"
    assert sc._max_quality(dasar + "?type=q90") == dasar
    # banner peringatan usia (?type=opti) sengaja TIDAK diubah, seperti extension
    assert sc._max_quality(dasar + "?type=opti") == dasar + "?type=opti"
    # parameter lain tetap dibawa
    assert sc._max_quality(dasar + "?type=q90&foo=1") == dasar + "?foo=1"
    assert sc._max_quality(dasar) == dasar
    print("✓ kualitas penuh: ?type=q90 dibuang, ?type=opti & parameter lain dibiarkan")


def test_kartu_listing():
    # Kartu halaman ranking: ada genre.
    ranking = """
    <a class="link _ranking_title_a" data-title-no="5001" data-webtoon-type="WEBTOON"
       href="https://www.webtoons.com/id/romantic-fantasy/serena/list?title_no=5001">
      <div class="image_wrap"><img src="https://cdn.test/a.jpg?type=q90"/></div>
      <div class="info_text"><strong class="title">Serena</strong>
        <div class="info_text_inner"><div class="genre">Kerajaan</div></div></div>
    </a>"""
    # Kartu halaman pencarian: TIDAK ada genre, cuma penulis, dan alt-nya kosong.
    pencarian = """
    <a class="link _card_item" data-title-no="150447" data-webtoon-type="CHALLENGE"
       href="https://www.webtoons.com/id/canvas/serenas-own-world/list?title_no=150447">
      <div class="info_text"><strong class="title">SERENA'S OWN WORLD</strong>
        <div class="author">Hanabee / Ryoko</div></div>
    </a>"""
    sc = _scraper()

    a = sc._listing_to_result(BeautifulSoup(ranking, "html.parser").select_one("a"))
    assert a['title'] == 'Serena' and a['title_no'] == '5001' and a['genre'] == 'Kerajaan'
    assert a['type'] == 'Webtoon'

    b = sc._listing_to_result(BeautifulSoup(pencarian, "html.parser").select_one("a"))
    assert b['title'] == "SERENA'S OWN WORLD"
    # data-webtoon-type berisi "CHALLENGE" -> tipe tetap ditentukan dari URL
    assert b['type'] == 'Canvas', f"tipe canvas salah: {b['type']!r}"
    assert b['genre'] == ''
    print("✓ kartu listing: judul/title_no/genre/tipe kebaca (canvas lewat URL, bukan atribut)")


# ----------------------------------------------------------------- penomoran
def test_nomor_dari_judul_prolog_dan_mini():
    """Judul situs: PROLOG + EPISODE n; prolog = 0, mini nempel 0.01."""
    sc = _scraper(payload=_payload(
        _episode(1, "PROLOG"),
        _episode(2, "EPISODE 1"),
        _episode(3, "EPISODE 2"),
        _episode(4, "[MINI] EPISODE 3"),
        _episode(5, "EPISODE 4"),
    ))
    chapters = sc._chapter_entries('1', 'webtoon')
    # dikembalikan terbaru -> terlama. Episode mini/bonus TIDAK memakai nomor
    # dari judulnya ("[MINI] EPISODE 3" bukan chapter 3), tapi nempel 0.01 di
    # episode sebelumnya (EPISODE 2 -> 2.01), sama seperti extension-nya.
    assert [c['number'] for c in chapters] == ['4', '2.01', '2', '1', '0'], \
        [c['number'] for c in chapters]
    assert chapters[-1]['title'] == "Chapter 0 PROLOG"
    assert chapters[0]['title'] == "Chapter 4 EPISODE 4"
    print("✓ penomoran: PROLOG jadi 0, mini/bonus nempel 0.01 di episode sebelumnya")


def test_nomor_judul_tidak_terbaca_urut_saja():
    """Kalau judulnya tidak memuat nomor sama sekali -> dinomori urut 1..N."""
    sc = _scraper(payload=_payload(
        _episode(1, "Awal Mula"),
        _episode(2, "Pertemuan"),
        _episode(3, "Perpisahan"),
    ))
    chapters = sc._chapter_entries('1', 'webtoon')
    assert [c['number'] for c in chapters] == ['3', '2', '1']
    print("✓ penomoran: judul tanpa angka -> urut 1..N")


def test_nomor_ganti_musim_digeser():
    """Season 2 yang nomornya balik ke 1 digeser setelah nomor tertinggi S1."""
    sc = _scraper(payload=_payload(
        _episode(1, "S1 Ep. 1"),
        _episode(2, "S1 Ep. 2"),
        _episode(3, "S2 Ep. 1"),
        _episode(4, "S2 Ep. 2"),
    ))
    chapters = sc._chapter_entries('1', 'webtoon')
    assert [c['number'] for c in chapters] == ['4', '3', '2', '1'], \
        [c['number'] for c in chapters]
    print("✓ penomoran: season 2 digeser (Ep.1 S2 jadi chapter 3, bukan nabrak S1)")


def test_nomor_judul_sama_dengan_nomor_berkas_cbz():
    """Nomor pertama di judul HARUS nomor chapter-nya.

    base.py menamai berkas dari angka pertama yang muncul di judul; kalau nomor
    chapter ditulis di belakang (atau judul episode mengandung angka lain lebih
    dulu), CBZ-nya bisa salah nomor / saling menimpa.
    """
    sc = _scraper(payload=_payload(
        _episode(1, "PROLOG"),
        _episode(2, "EPISODE 1"),
        _episode(3, "EP. 138 - HAL YANG INDAH ITU"),
        _episode(4, "[BONUS] EPISODE 139"),
        _episode(5, "S2 EP. 5"),
    ))
    for chapter in sc._chapter_entries('1', 'webtoon'):
        cocok = sc.NOMOR_JUDUL_RE.search(chapter['title'])
        assert cocok is not None, chapter['title']
        assert cocok.group() == chapter['number'], \
            f"{chapter['title']!r}: angka pertama {cocok.group()!r} != nomor {chapter['number']!r}"
    print("✓ nomor di judul = nomor berkas CBZ (angka pertama selalu nomor chapter)")


def test_chapter_dibuang_kalau_tautan_kembar():
    """Satu chapter dengan tautan viewer yang sama tidak boleh muncul dua kali."""
    sama = "/id/uji/seri/ep-1/viewer?title_no=1&episode_no=1"
    sc = _scraper(payload=_payload(
        _episode(1, "EPISODE 1", sama),
        _episode(2, "EPISODE DUPLIKAT", sama),
        _episode(3, "EPISODE 2"),
    ))
    chapters = sc._chapter_entries('1', 'webtoon')
    assert len(chapters) == 2, [c['title'] for c in chapters]
    assert len({c['url'] for c in chapters}) == 2
    print("✓ chapter dengan tautan viewer kembar cuma diambil sekali")


def test_canvas_pakai_reading_language_code():
    """Endpoint canvas harus menyertakan readingLanguageCode=id."""
    dipanggil = {}

    class _Rekam(WebtoonsScraper):
        def _api_get(self, path, params=None):
            dipanggil['path'] = path
            dipanggil['params'] = params
            return _payload(_episode(1, "Episode 1"))

    sc = _Rekam(tempfile.mkdtemp(prefix="test_webtoons_"))
    sc._chapter_entries('304446', 'canvas')
    assert dipanggil['path'] == '/api/v1/canvas/304446/episodes'
    assert dipanggil['params'].get('readingLanguageCode') == 'id'
    assert dipanggil['params'].get('pageSize') == '99999'

    sc._chapter_entries('5001', 'webtoon')
    assert dipanggil['path'] == '/api/v1/webtoon/5001/episodes'
    assert 'readingLanguageCode' not in dipanggil['params'], \
        "endpoint webtoon tidak boleh dikirimi readingLanguageCode"
    print("✓ endpoint canvas/webtoon dipilih benar (canvas + readingLanguageCode=id)")


class _FakeResp:
    """Balasan HTTP palsu buat nguji _download_image_with_retry tanpa jaringan."""

    def __init__(self, data: bytes, tipe: str, status: int = 200):
        self.content = data
        self.headers = {'Content-Type': tipe}
        self.status_code = status

    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP {self.status_code}")


def test_gambar_pemisah_kecil_diterima_balasan_error_ditolak():
    """PNG pemisah 255 B dari CDN Webtoons bukan kegagalan unduh.

    Diuji live: gambar pemisah itu balas HTTP 200 image/png 255 byte, dan
    pemeriksaan `len < 1000` di base.py membuatnya dilaporkan "halaman gagal"
    padahal datang normal.
    """
    sc = _scraper()
    sc.RETRY_DELAY = 0

    kecil = b'\x89PNG\r\n\x1a\n' + b'0' * 247          # 255 byte
    besar = b'\xff\xd8\xff' + b'0' * 5000               # JPEG normal

    sc.session.get = lambda url, **kw: _FakeResp(kecil, 'image/png')
    assert sc._download_image_with_retry('https://cdn.test/pemisah.png') == kecil, \
        "gambar kecil tapi benar-benar gambar harus diterima"

    sc.session.get = lambda url, **kw: _FakeResp(besar, 'image/jpeg')
    assert sc._download_image_with_retry('https://cdn.test/hal.jpg') == besar

    # Balasan error tetap ditolak: status 403 dan/atau body kecil bukan gambar.
    sc.session.get = lambda url, **kw: _FakeResp(b'forbidden', 'text/html', 403)
    assert sc._download_image_with_retry('https://cdn.test/hal.jpg') is None
    sc.session.get = lambda url, **kw: _FakeResp(b'forbidden', 'text/html')
    assert sc._download_image_with_retry('https://cdn.test/hal.jpg') is None
    sc.session.get = lambda url, **kw: _FakeResp(b'', 'image/png')
    assert sc._download_image_with_retry('https://cdn.test/hal.jpg') is None
    print("✓ gambar pemisah kecil (image/*) diterima, balasan error tetap ditolak")


def test_api_kosong_tidak_error():
    sc = _scraper(payload=None)
    assert sc._chapter_entries('1', 'webtoon') == []
    sc2 = _scraper(payload={'result': {'episodeList': []}})
    assert sc2._chapter_entries('1', 'webtoon') == []
    print("✓ balasan API kosong/gagal -> daftar chapter kosong (bukan error)")


if __name__ == "__main__":
    test_format_number()
    test_tipe_dan_title_no_dari_url()
    test_kualitas_penuh()
    test_kartu_listing()
    test_nomor_dari_judul_prolog_dan_mini()
    test_nomor_judul_tidak_terbaca_urut_saja()
    test_nomor_ganti_musim_digeser()
    test_nomor_judul_sama_dengan_nomor_berkas_cbz()
    test_chapter_dibuang_kalau_tautan_kembar()
    test_canvas_pakai_reading_language_code()
    test_gambar_pemisah_kecil_diterima_balasan_error_ditolak()
    test_api_kosong_tidak_error()
    print("\n✅ SEMUA TEST LULUS")
