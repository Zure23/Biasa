# 📚 Comic Scraper

Download manga dari situs Indonesia: **komiku.org**, **komikindo.ch**, dan **softkomik.co**

## 🚀 Features

- 🔍 Search manga by title
- 📖 Get manga details (genres, synopsis, info)
- 📥 Download single chapter atau multiple chapters
- 📁 Organized folder structure:
  ```
  downloads/
  └── Manga_Title/
      ├── cover.jpg
      ├── info.json
      └── Chapter_001/
          ├── 001.webp
          ├── 002.webp
          └── ...
  ```

## 📦 Installation

```bash
cd comic-scraper
pip install -r requirements.txt
```

## 🎯 Usage

### Interactive Mode

```bash
python main.py
```

### Command Line Arguments

```bash
# Search and download from komiku.org
python main.py -s komiku -q "martial peak" -d all

# Download specific chapters
python main.py -s komiku -q "martial peak" -d "1,2,3"

# Download chapter range
python main.py -s komiku -q "martial peak" -d "1-10"

# Custom output directory
python main.py -s komiku -q "martial peak" -d all -o my_comics

# softkomik.co
python main.py -s softkomik -q "solo leveling" -d all
```

### Impor ke GitHub Release

Setelah unduhan selesai, muncul menu:

```
Unduhan selesai
  1   Masukkan judul lain        unduh judul berikutnya dari situs yang sama
  2   Impor                      zip semua unduhan, rilis ke github, lalu kosongkan folder
```

Pilih `2` untuk:

1. meng-zip seluruh isi folder unduhan,
2. membuat GitHub Release dengan versi yang **naik otomatis** (`v7.4.8` -> `v7.4.9`),
3. **hanya kalau rilisnya berhasil**: menghapus zip dan mengosongkan folder unduhan,

sambil ada animasi proses (spinner). Setelah selesai, tampilan kembali ke prompt
judul situs yang sama.

- Versi diambil dari tag rilis GitHub + memory lokal (`.rilis-versi.json`), jadi
  tidak akan bentrok walau dijalankan berulang. Kalau tag tetap terpakai, versinya
  dinaikkan lagi otomatis dan dicoba ulang.
- Kalau rilis gagal, folder unduhan **tidak** dihapus (aman diulang).
- Komponen versi bisa diatur lewat env: `RILIS_BUMP=patch|minor|major` (bawaan `patch`).
- Tanpa masuk menu, bisa juga langsung dari terminal:

  ```bash
  ./impor                 # zip + rilis + kosongkan folder unduhan
  ./impor --dry-run       # lihat rencananya saja, tidak menyentuh berkas
  ./impor --tanya         # minta konfirmasi dulu sebelum rilis & hapus
  ./impor -o folder-lain  # pakai folder unduhan lain (bawaan: downloads)
  ```

  `./impor` langsung memproses (dengan animasi spinner). Padanannya:
  `python3 -m scraper.impor`.

## 📋 Supported Sites

| Site | Status | Cloudflare |
|------|--------|------------|
| komiku.org | ✅ Working | No |
| komikindo.ch | ⚠️ Partial | Yes (needs cloudscraper) |
| softkomik.co | ✅ Working | No |

## 📁 Output Structure

### Info JSON Format

```json
{
  "title": "Martial Peak",
  "genres": ["Action", "Adventure", "Fantasy"],
  "synopsis": "Bercerita tentang...",
  "info": {
    "Judul": "Martial Peak",
    "Tipe": "Manhua",
    "Status": "Ongoing",
    "Author": "Momo"
  },
  "source": "komiku.org",
  "url": "https://komiku.org/manga/martial-peak/"
}
```

## ⚠️ Notes

- Gunakan tool ini dengan bijak
- Hormati hak cipta creator
- Jangan download terlalu cepat (ada delay antar chapter)
- komikindo.ch membutuhkan `cloudscraper` untuk bypass Cloudflare
- softkomik.co butuh token sesi (`X-Token`/`X-Sign`) dari `/api/session/*` untuk
  mengambil daftar chapter dan daftar gambar; token diambil otomatis dan
  di-cache oleh scraper. Detail endpoint ada di komentar `scraper/softkomik.py`.
- Gambar softkomik.co pakai "trap image": kalau URL gambarnya tidak diberi
  `?id=...` atau permintaannya tidak membawa header `Referer` dari situsnya,
  CDN-nya tidak memberi error tapi mengalihkan ke `/baca-image.jpeg` (gambar
  promosi berukuran besar). Scraper sudah mengirim keduanya dan mengenali
  jebakan itu dari URL akhir balasannya. Selain jebakan redirect itu, scraper
  mengikuti CDN: balasan yang benar-benar gambar tetap dipakai apa adanya,
  termasuk halaman kosong solid hitam/putih yang ukurannya kecil (~826 byte).
  Kalau situsnya mengganti kunci `id`, chapter yang gambarnya dialihkan ke
  jebakan akan DILEWAT (tidak ditulis ke CBZ) dan ada peringatannya di
  terminal -- bukan diam-diam tersimpan sebagai halaman palsu.
- Unduhan softkomik.co dibuat mengikuti cara Tachiyomi/Mihon (yang hampir tidak
  pernah bolong): permintaan gambar dibatasi ~5 yang jalan bareng untuk seluruh
  proses (`IMAGE_SLOTS`, sama dengan `Semaphore(parallelPageLimit)` bawaannya
  Tachiyomi), jadi permintaannya mengalir tetap -- bukan meledak puluhan
  sekaligus saat banyak chapter jalan paralel. Banyaknya worker tetap seperti
  semula; itu cuma jadi panjang antrean.
- CBZ softkomik **hanya ditulis kalau semua halaman ada** (`WAJIB_LENGKAP = True`,
  sama dengan pemeriksaan `isDownloadSuccessful` Tachiyomi). Chapter yang kurang
  halaman -- gagal unduh, atau halamannya gagal di-merge/di-encode -- tidak
  ditulis setengah jadi: chapter itu ditandai gagal, diulang di akhir unduhan,
  dan nomor halaman yang hilang dicatat di `logs/halaman-hilang.log`. Jadi gambar
  "kepotong" di CBZ (beberapa halaman hilang dalam satu strip) tidak akan ikut
  tersimpan. Dua setelan di atas (`IMAGE_SLOTS`, `WAJIB_LENGKAP`) **hanya**
  untuk softkomik.co; provider lain tetap seperti semula (batas 80%, tanpa batas
  slot gambar, pesan kegagalan yang sama).
- Koneksi softkomik.co bisa berubah sendiri di mesin yang dipakai bergantian
  (codespace/container di-restart, jaringan pindah, IP publik ganti). Cookie
  situs dan token sesinya terikat ke koneksi itu, jadi begitu ada permintaan
  yang gagal, scraper **membangun ulang sesinya otomatis** (beranda dikunjungi
  lagi, token dibuang lalu diambil lagi) sebelum menyerah. Kalau tetap gagal,
  penyebabnya ditulis di layar -- bukan lagi dilaporkan sebagai
  "Tidak ditemukan hasil!" yang bikin kelihatan situsnya rusak.
- Buat memastikan ini soal koneksi/sesi atau soal judulnya, jalankan dari
  folder `sc/`:
  ```bash
  python3 -m scraper.softkomik
  ```
  Outputnya: umur cookie login, status login, akses beranda, percobaan
  pencarian, dan apakah token sesi (beserta `contentAccess`) bisa diambil.
- Judul softkomik.co bertag Ecchi/Mature (kategori SENSITIVE) gambarnya dikunci
  situsnya sampai login. Saat itu kejadian, scraper menanyakan email+password di
  terminal **sekali**, lalu menyimpan cookie sesinya ke `sc/.softkomik-cookies.json`
  sehingga jalan berikutnya tidak ditanya lagi. Untuk mesin tanpa terminal
  (cron/SSH non-interaktif), set `SOFTKOMIK_EMAIL` dan `SOFTKOMIK_PASSWORD`.
  Password tidak pernah disimpan — hanya cookie. Hapus file cookie itu kalau
  ingin login ulang dengan akun lain.

## 🔧 Requirements

- Python 3.8+
- requests
- beautifulsoup4
- cloudscraper (untuk komikindo.ch)
- rich (untuk terminal UI)
