"""
Scraper for komikindo.ch with 10 parallel batch workers
"""
import re
import json
import time
from typing import Optional, List, Dict, Any
from bs4 import BeautifulSoup
from .base import BaseScraper


class KomikindoScraper(BaseScraper):
    """Scraper for komikindo.ch with batch workers"""
    
    BASE_URL = "https://komikindo.ch"
    # Cloudflare aktif -> jaga-jaga tetap 5 worker biar kagak kena rate-limit
    MAX_WORKERS = 5
    
    def _create_session(self):
        """Create session with cloudscraper for Cloudflare bypass"""
        try:
            import cloudscraper
            session = cloudscraper.create_scraper(
                browser={
                    'browser': 'chrome',
                    'platform': 'windows',
                    'desktop': True,
                }
            )
            session.headers.update(self.HEADERS)
            return session
        except ImportError:
            print("  cloudscraper belum terpasang, pakai requests biasa")
            return super()._create_session()
    
    def search(self, query: str) -> List[Dict[str, Any]]:
        """Search for manga on komikindo.ch"""
        url = f"{self.BASE_URL}/?s={query}&post_type=wp-manga"
        html = self._get_page(url)
        
        if not html:
            return []
        
        soup = BeautifulSoup(html, 'html.parser')
        results = []
        
        for item in soup.find_all('div', class_='animepost'):
            try:
                link = item.find('a', href=True, title=True)
                if not link:
                    continue
                
                href = link.get('href', '')
                title = link.get('title', '').replace('Komik ', '')
                
                cover_url = ''
                img = item.find('img')
                if img:
                    # item list pakai thumbnail -223x319 -> upgrade ke file asli
                    cands = self._cover_candidates_from_img(img)
                    cover_url = cands[0] if cands else ''
                
                manga_type = ''
                type_badge = item.find('span', class_=re.compile(r'typeflag'))
                if type_badge:
                    classes = type_badge.get('class', [])
                    for cls in classes:
                        if cls.startswith('typeflag'):
                            manga_type = cls.replace('typeflag', '').strip()
                
                rating = ''
                rating_div = item.find('div', class_='rating')
                if rating_div:
                    i_tag = rating_div.find('i')
                    if i_tag:
                        rating = i_tag.get_text(strip=True)
                
                results.append({
                    'title': title,
                    'url': href,
                    'cover_url': cover_url,
                    'type': manga_type,
                    'rating': rating,
                })
            except Exception as e:
                continue
        
        # Situs mengurutkan hasil menurut popularitas; judul yang persis diketik
        # user ditarik ke atas dulu (lihat BaseScraper._urut_hasil_pencarian).
        return self._urut_hasil_pencarian(query, results)
    
    def get_manga_detail(self, url: str) -> Optional[Dict[str, Any]]:
        """Get manga details from komikindo.ch"""
        html = self._get_page(url)
        
        if not html:
            return None
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # Get title
        title = ''
        title_tag = soup.find('h1', class_='entry-title')
        if title_tag:
            title_text = title_tag.get_text(strip=True)
            title = title_text.replace('Komik', '').strip()
        
        # Get cover image — HARUS versi jernih, bukan thumbnail.
        # Di komikindo: og:image = file asli (tanpa suffix -WxH),
        # sedangkan div.thumb > img.src = thumbnail kecil (mis. 223x319).
        cover_candidates = []
        og_image = soup.find('meta', property='og:image')
        if og_image and og_image.get('content'):
            cover_candidates.append(self._upgrade_image_url(og_image['content']))
        
        thumb_div = soup.find('div', class_='thumb')
        if thumb_div:
            cover_candidates.extend(self._cover_candidates_from_img(thumb_div.find('img')))
        
        cover_candidates = self._dedupe_urls(cover_candidates)
        cover_url = cover_candidates[0] if cover_candidates else ''
        
        # Get info
        raw_info = {}
        info_div = soup.find('div', class_='infox')
        if info_div:
            spe_div = info_div.find('div', class_='spe')
            if spe_div:
                for span in spe_div.find_all('span'):
                    b_tag = span.find('b')
                    if b_tag:
                        key = b_tag.get_text(strip=True).rstrip(':')
                        value_text = span.get_text(strip=True)
                        value_text = value_text.replace(b_tag.get_text(strip=True), '').strip()
                        if value_text:
                            raw_info[key] = value_text
        
        # Get genres
        genres = []
        genre_div = soup.find('div', class_='genre-info')
        if genre_div:
            for a in genre_div.find_all('a'):
                genres.append(a.get_text(strip=True))
        
        # Get synopsis
        synopsis = ''
        sinopsis_div = soup.find('div', id='sinopsis')
        if sinopsis_div:
            desc_div = sinopsis_div.find('div', class_='entry-content')
            if desc_div:
                synopsis = desc_div.get_text(strip=True)
                synopsis = re.sub(r'\s+', ' ', synopsis)
        
        # Get chapters
        chapters = []
        chapter_list = soup.find('div', id='chapter_list')
        if chapter_list:
            for li in chapter_list.find_all('li'):
                a = li.find('a', href=True)
                if a:
                    href = a.get('href', '')
                    chapter_tag = li.find('chapter')
                    if chapter_tag:
                        name = f"Chapter {chapter_tag.get_text(strip=True)}"
                    else:
                        name = a.get_text(strip=True)
                    chapters.append({
                        'title': name,
                        'url': href,
                    })
        
        # Simplified info
        info = {
            'title': title,
            'genres': genres,
            'synopsis': synopsis,
            'author': raw_info.get('Pengarang', ''),
            'type': raw_info.get('Jenis Komik', ''),
            'status': raw_info.get('Status', ''),
            'total_chapters': len(chapters),
        }
        
        return {
            'title': title,
            'cover_url': cover_url,
            'cover_candidates': cover_candidates,
            'info': info,
            'chapters': chapters,
        }
    
    def get_chapter_images_ordered(self, url: str) -> List[Dict[str, Any]]:
        """
        Get all image URLs for a chapter WITH CORRECT ORDER.
        """
        html = self._get_page(url)
        
        if not html:
            return []
        
        soup = BeautifulSoup(html, 'html.parser')
        ordered_images = []
        
        # Find img-landmine div
        landmine = soup.find('div', class_='img-landmine')
        
        if landmine:
            all_imgs = landmine.find_all('img')
            
            order = 0  # counter kontigu: nomor urut selalu 1..N sesuai urutan DOM
            for img in all_imgs:
                src = img.get('src', '') or img.get('data-src', '')
                
                if not src or src.startswith('data:'):
                    continue
                if 'blogger.googleusercontent.com' in src:
                    continue
                
                order += 1
                ordered_images.append({
                    'order': order,
                    'url': src.strip(),
                })
        
        # Fallback
        if not ordered_images:
            chapter_img_div = soup.find('div', class_='chapter-image')
            if not chapter_img_div:
                chapter_img_div = soup.find('div', id='Baca_Komik')
            
            if chapter_img_div:
                all_imgs = chapter_img_div.find_all('img')
                order = 0
                for img in all_imgs:
                    src = img.get('src', '') or img.get('data-src', '')
                    if not src or src.startswith('data:'):
                        continue
                    if 'blogger.googleusercontent.com' in src:
                        continue
                    
                    order += 1
                    ordered_images.append({
                        'order': order,
                        'url': src.strip(),
                    })
        
        return ordered_images
    
    def get_chapter_images(self, url: str) -> List[str]:
        """Get all image URLs for a chapter"""
        ordered = self.get_chapter_images_ordered(url)
        return [img['url'] for img in ordered]
    
    def download_manga(self, manga_url: str, max_workers: int = None, progress=None,
                       chapters=None, target_dir=None) -> bool:
        """Download manga using base class with parallel workers"""
        return super().download_manga(manga_url, max_workers=max_workers, progress=progress,
                                      chapters=chapters, target_dir=target_dir)
