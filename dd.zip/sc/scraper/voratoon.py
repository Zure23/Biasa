"""
Scraper for voratoon.com (API publik api.voratoon.com + gambar di cdn.voratoon.com)

Endpoint/alur diambil dari extension Tachiyomi/Mihon "VoraToon" (sample/VoraToon.kt)
dan sudah dicek langsung ke API-nya:
  1. Cari judul      : GET {API}/series?includeMeta=true&take=..&page=..&title=<q>
  2. Daftar populer  : GET {API}/series?...&sort=popularity&sortOrder=desc
  3. Detail manga    : GET {API}/series/{slug}                 -> data.data
  4. Daftar chapter  : GET {API}/series/{slug}/chapters        -> data[].data.index
  5. Isi chapter     : GET {API}/series/{slug}/chapters/{idx}  -> data.data.images[]
  6. Gambar          : URL absolut di cdn.voratoon.com (sudah urut 001, 002, ...)

Catatan penting:
- Chapter TIDAK punya judul; yang ada cuma `index` (nomor bab). Judul chapter
  dibentuk "Chapter <index>" supaya cocok dengan format situs lain dan dengan
  pemilih chapter di CLI (yang membaca angka dari judulnya).
- Daftar gambar sudah urut dari server (001..N), jadi tidak perlu menebak
  urutan dari atribut HTML seperti di komiku/komikindo.
- CDN gambarnya tidak memakai jebakan seperti softkomik: permintaan tanpa
  Referer pun dibalas file asli (sudah diuji). Referer tetap dikirim karena
  itu yang dipakai extension-nya.
- Extension aslinya membatasi 3 permintaan serentak ke host api.voratoon.com
  (`rateLimit(3)`). Di sini batas itu dijaga lewat semaphore supaya banyak
  worker chapter tidak menghujani endpoint API-nya. Gambar tidak dibatasi
  (host CDN terpisah).
"""
import re
import time
import threading
from typing import Any, Dict, List, Optional
from urllib.parse import quote

from .base import BaseScraper


class VoraToonScraper(BaseScraper):
    """Scraper for voratoon.com"""

    BASE_URL = "https://voratoon.com"
    API_URL = "https://api.voratoon.com"

    # 1 chapter = 1 permintaan API (daftar gambar) + download gambar paralel.
    # Worker chapter dinaikkan ke 8 biar banyak chapter jalan bareng; endpoint
    # API TETAP dibatasi 3 serentak lewat API_CONCURRENCY, jadi naiknya worker
    # tidak bikin menghujani API-nya -- permintaan API cuma menumpuk sebentar
    # lalu jalan begitu slot kosong. Gambar (cdn.voratoon.com) tidak dibatasi.
    MAX_WORKERS = 8
    INNER_DOWNLOAD_WORKERS = 4

    # Hasil yang dipakai CLI. Endpoint /series mengurut menurut popularitas
    # (bukan kedekatan judul), jadi judul yang persis diketik user bisa duduk
    # jauh di halaman belakang walau memang ada di situsnya. Karena itu
    # pencarian mengambil beberapa halaman dulu (lihat SEARCH_TAKE /
    # SEARCH_MAX_PAGES) sebelum dirapikan dan dipotong ke SEARCH_LIMIT.
    SEARCH_LIMIT = 20
    SEARCH_TAKE = 60        # hasil per permintaan API saat mencari
    SEARCH_MAX_PAGES = 3    # batas halaman kalau judul persis belum ketemu

    # Batas permintaan serentak ke api.voratoon.com (meniru rateLimit(3)
    # extension). Semua panggilan API lewat _api_get supaya patuh batas ini.
    API_CONCURRENCY = 3
    API_RETRIES = 3
    API_RETRY_DELAY = 1

    # Nomor halaman di akhir URL (chapter): ".../chapters/918", ".../918",
    # atau chapter bonus berdesimal ".../chapters/348.5".
    CHAPTER_INDEX_RE = re.compile(r'/(?:chapters/)?(\d+(?:\.\d+)?)/?$')
    SERIES_SLUG_RE = re.compile(r'/series/([^/?#]+)')

    IMAGE_HEADERS = {
        'Referer': BASE_URL + '/',
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
    }

    def __init__(self, download_dir: str = "downloads"):
        super().__init__(download_dir)
        self._api_sem = threading.BoundedSemaphore(self.API_CONCURRENCY)

    # ---------------------------------------------------------------- API
    def _api_get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Optional[Any]:
        """GET JSON dari API, dengan batas serentak + percobaan ulang.

        `path` boleh path relatif ("/series") atau URL lengkap. Return None
        kalau semua percobaan gagal -- pemanggil yang memutuskan artinya.
        """
        url = path if path.startswith('http') else f"{self.API_URL}{path}"
        for attempt in range(self.API_RETRIES):
            try:
                with self._api_sem:
                    resp = self.session.get(url, params=params, timeout=30,
                                            headers={'Accept': 'application/json'})
                resp.raise_for_status()
                return resp.json()
            except Exception:
                if attempt < self.API_RETRIES - 1:
                    time.sleep(self.API_RETRY_DELAY * (attempt + 1))
        return None

    @staticmethod
    def _rows(payload: Optional[Any]) -> List[Dict[str, Any]]:
        """Ambil list `data` dari balasan API ({status, message, data, meta})."""
        if not isinstance(payload, dict):
            return []
        rows = payload.get('data')
        return rows if isinstance(rows, list) else []

    def _series_params(self, page: int, sort: str,
                       take: Optional[int] = None) -> Dict[str, Any]:
        return {
            'includeMeta': 'true',
            'take': take or self.SEARCH_LIMIT,
            'page': page,
            'sort': sort,
            'sortOrder': 'desc',
        }

    @classmethod
    def _series_row_to_result(cls, row: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Ubah 1 baris list series jadi hasil pencarian untuk CLI."""
        data = row.get('data') or {}
        slug = (data.get('slug') or '').strip()
        if not slug:
            return None
        total = str(data.get('totalChapters') or '').strip()
        return {
            'title': data.get('title') or slug,
            'url': f"{cls.BASE_URL}/series/{slug}",
            'slug': slug,
            'type': data.get('format') or data.get('type') or '',
            'cover_url': data.get('coverImage') or '',
            'chapter_latest': f"Chapter {total}" if total.isdigit() else total,
            'rating': data.get('rating') if data.get('rating') not in (None, '') else '',
        }

    # ---------------------------------------------------------------- publik
    def search(self, query: str) -> List[Dict[str, Any]]:
        """Cari judul lewat endpoint /series (filter `title`).

        Endpoint ini mengurut menurut popularitas, bukan kedekatan judul, jadi
        judul yang persis diketik user (mis. "The Villain") bisa tidak ada di
        halaman pertama walau serinya memang ada (di sini "The Villain" baru
        muncul di posisi ~29 dari 79). Makanya beberapa halaman pertama diambil
        dulu -- berhenti begitu judul persis sudah ketemu -- baru judul yang
        persis diketik user ditarik ke paling atas
        (lihat BaseScraper._urut_hasil_pencarian).
        """
        q = (query or '').strip()
        if not q:
            return []

        q_norm = self._normalisasi_judul(q)
        results: List[Dict[str, Any]] = []

        for page in range(1, self.SEARCH_MAX_PAGES + 1):
            params = self._series_params(page=page, sort='popularity',
                                         take=self.SEARCH_TAKE)
            params['title'] = q
            payload = self._api_get('/series', params=params)
            rows = self._rows(payload)
            if not rows:
                break

            for row in rows:
                item = self._series_row_to_result(row)
                if item:
                    results.append(item)

            # Judul persis sudah ketemu? Halaman berikutnya tidak perlu diambil.
            if any(self._normalisasi_judul(r['title']) == q_norm
                   for r in results):
                break

            meta = payload.get('meta') or {}
            if page >= (meta.get('lastPage') or page):
                break

        # API mengurut menurut popularitas; judul yang persis diketik user ditarik
        # ke atas dulu, baru dipotong ke SEARCH_LIMIT
        # (lihat BaseScraper._urut_hasil_pencarian).
        results = self._urut_hasil_pencarian(query, results)
        return results[:self.SEARCH_LIMIT]

    def get_popular(self, page: int = 1) -> List[Dict[str, Any]]:
        """Judul populer (urutan default, dipakai sebagai cadangan)."""
        payload = self._api_get('/series',
                                params=self._series_params(page, 'popularity'))
        return [r for r in (self._series_row_to_result(row)
                            for row in self._rows(payload)) if r]

    def slug_from_url(self, url: str) -> str:
        """Ambil slug dari URL seri/chapter (`/series/<slug>`)."""
        match = self.SERIES_SLUG_RE.search(url or '')
        return match.group(1).strip() if match else ''

    def chapter_index_from_url(self, url: str) -> str:
        """Ambil nomor chapter dari URL-nya, '' kalau ini bukan URL chapter."""
        match = self.CHAPTER_INDEX_RE.search((url or '').rstrip('/'))
        return match.group(1) if match else ''

    def get_manga_detail(self, url: str) -> Optional[Dict[str, Any]]:
        """Detail manga + daftar chapter dari API."""
        slug = self.slug_from_url(url)
        if not slug:
            return None

        payload = self._api_get(f"/series/{quote(slug)}")
        if payload is None or not (payload.get('data')):
            return None
        row = payload['data']
        data = row.get('data') or {}
        if not data:
            return None

        title = data.get('title') or slug
        cover_url = data.get('coverImage') or ''
        genres = [g.get('data', {}).get('name', '')
                  for g in (data.get('genres') or [])]
        genres = [g for g in genres if g]

        chapters = self._chapter_entries(slug)
        total = str(data.get('totalChapters') or '').strip()

        info = {
            'title': title,
            'alternative_title': data.get('nativeTitle') or '',
            'type': data.get('format') or data.get('type') or '',
            'author': data.get('author') or '',
            'artist': data.get('author') or '',
            'status': data.get('status') or '',
            'rating': data.get('rating') if data.get('rating') not in (None, '') else '',
            'release_date': data.get('releaseDate') or '',
            'total_chapters': len(chapters) or (int(total) if total.isdigit() else 0),
        }

        return {
            'title': title,
            'cover_url': cover_url,
            'cover_candidates': [cover_url] if cover_url else [],
            'genres': genres,
            'synopsis': (data.get('synopsis') or '').strip(),
            'info': info,
            'total_chapters': info['total_chapters'],
            'source': 'voratoon.com',
            'source_url': f"{self.BASE_URL}/series/{slug}",
            'chapters': chapters,
        }

    def _chapter_entries(self, slug: str) -> List[Dict[str, Any]]:
        """Daftar chapter (urut terbaru -> terlama, sama seperti API).

        Judul dibentuk "Chapter <index>" karena API tidak menyimpan judul bab.
        `url` sengaja memakai endpoint API chapter-nya: langsung dipakai
        get_chapter_images_ordered dan tidak bergantung halaman webnya.
        """
        payload = self._api_get(f"/series/{quote(slug)}/chapters")
        rows = self._rows(payload)

        chapters = []
        dilihat = set()
        for row in rows:
            index = (row.get('data') or {}).get('index')
            if index is None:
                continue
            num = str(index).strip()
            if not num or num in dilihat:
                continue
            dilihat.add(num)
            chapters.append({
                'title': f"Chapter {num}",
                'url': f"{self.API_URL}/series/{quote(slug)}/chapters/{num}",
                'number': num,
            })
        return chapters

    def get_chapter_images_ordered(self, url: str) -> List[Dict[str, Any]]:
        """Daftar gambar 1 chapter (API sudah mengirimnya urut 001..N)."""
        slug = self.slug_from_url(url)
        index = self.chapter_index_from_url(url)
        if not slug or not index:
            return []

        payload = self._api_get(
            f"/series/{quote(slug)}/chapters/{quote(index)}")
        if payload is None:
            return []
        data = (payload.get('data') or {}).get('data') or {}
        images = data.get('images') or []

        return [
            {'order': i, 'url': src}
            for i, src in enumerate(images, 1)
            if isinstance(src, str) and src.strip()
        ]

    def get_chapter_images(self, url: str) -> List[str]:
        """Get all image URLs for a chapter (backward compatible)"""
        ordered = self.get_chapter_images_ordered(url)
        return [img['url'] for img in ordered]

    def _download_image_with_retry(self, url: str) -> Optional[bytes]:
        """Unduh gambar halaman pakai Referer situsnya (seperti extension-nya)."""
        for attempt in range(self.MAX_RETRIES):
            try:
                resp = self.session.get(url, timeout=30, headers=self.IMAGE_HEADERS)
                resp.raise_for_status()
                data = resp.content
                if len(data) < 1000:      # kemungkinan balasan error, bukan gambar
                    raise Exception("Image data too small")
                return data
            except Exception:
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY)
        return None

    def download_manga(self, manga_url: str, max_workers: int = None, progress=None,
                       chapters=None, target_dir=None) -> bool:
        """Unduh pakai mesin base.py (tanpa perlakuan khusus).

        `target_dir` diteruskan apa adanya: mode paralel sudah menentukan folder
        milik judul ini, jadi base tidak perlu menghitung ulang dari judul.
        """
        return super().download_manga(manga_url, max_workers=max_workers,
                                      progress=progress, chapters=chapters,
                                      target_dir=target_dir)
